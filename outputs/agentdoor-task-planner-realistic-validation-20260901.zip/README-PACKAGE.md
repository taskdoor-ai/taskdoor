# AgentDoor 任务规划 Skill 验证包

本包只包含高拟真合成数据、候选规划 Skill、离线校验器与已记录运行；没有生产数据、生产访问或任务写入。

- 从 `skills/agentdoor-task-planner/SKILL.md` 开始。
- 查看 `skills/agentdoor-task-planner/evals/realistic-report.md` 获取结论。
- 打开 `skills/agentdoor-task-planner/evals/review.html` 复核 139 份记录。
- 按 `skills/agentdoor-task-planner/evals/tomorrow-validation.md` 重新盲测。
- `${PACKAGE_ROOT}` 是打包时替换本机工作区路径使用的逻辑占位符。
- `${TMPDIR}` 是可重跑命令或历史临时运行来源的环境变量占位符；归档映射见各运行的 `artifact-path-map.json`。
