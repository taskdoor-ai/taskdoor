import { useEffect, useMemo, useRef, useState } from "react";
import { TaskCreationPage } from "./components/TaskCreationPage";
import type { PrimarySection } from "./components/WorkspaceSidebar";
import { WorkspaceTopbar } from "./components/WorkspaceTopbar";
import { PersonDirectoryProvider } from "./components/PersonDirectory";
import { TaskWorkspace } from "./components/TaskWorkspace";
import { PersonalWorkbench } from "./components/PersonalWorkbench";
import { CliConnectionDialog } from "./components/CliConnectionDialog";
import { TaskDetail, type TaskAttentionTarget } from "./components/TaskDetail";
import type { TaskRelationSummary } from "./components/TaskRelationsSection";
import type { TaskDateRange } from "./components/TaskDateRangePicker";
import { taskIconOptions, taskIconToneOptions } from "./components/TaskIcon";
import { AiConnectionPage } from "./components/AiConnectionPage";
import { TagManagementPage } from "./components/TagManagementPage";
import { PersonalCenterModal, type PersonalCenterModule } from "./components/PersonalInfoDialog";
import { createInitialTaskListFilters, type TaskListFilters } from "./components/taskListFilters";
import { createWorkspaceTaskDetail, taskDetailMocks, type TaskActivityChange, type TaskActivityMock, type TaskActivityType, type TaskDetailId, type TaskDetailMock } from "./data/taskDetailMocks";
import { initialTags, type TagDefinition } from "./data/tagGroups";
import { normalizeWorkspaceNodes, workspaceNodes as initialWorkspaceNodes, workspaceRootId, type TaskIconName, type TaskIconTone, type TaskNode, type WorkspaceNode } from "./data/workspaceNodes";
import { loadPersonalCenterState, type PersonalCenterState } from "./data/memberProfiles";
import { creatorCommerceMembers } from "./data/creatorCommerceScenario";
import { legacyTaskSources, loadLatestLegacyTaskSnapshot, loadLegacyTaskSnapshots, persistLegacyTaskSnapshots, type LegacyTaskSnapshot } from "./data/legacyTaskSnapshots";
import type { TaskPlanDraft } from "./lib/taskAssistantProtocol";
import { appendTaskActivity, createTaskChangeActivity, parseTaskActivityStore, type TaskActivityStore } from "./lib/taskActivity";
import { createWorkspaceTasksFromDraft } from "./lib/workspaceTaskCreation";
import { addWorkspaceSubtask, deleteWorkspaceSubtask, getSubtaskDeletionPreview, getSubtaskDeletionWrites, type NewSubtaskDraft } from "./lib/workspaceSubtaskEditing";
import { clearTaskFileDraftSessions } from "./lib/taskFileDrafts";
import { commitWorkspaceScenarioReset, resolveWorkspaceScenarioReset } from "./lib/workspaceScenarioReset";
import { updateWorkspaceTaskStatus } from "./lib/workspaceTaskUpdates";
import { applySavedTaskAiAdjustment, createSavedTaskAiContext, getTaskDefinitionGoal } from "./lib/taskAiAdjustmentAdapters";
import { commitTaskAiStorage, recoverTaskAiStorage } from "./lib/taskAiAdjustmentStorage";
import type { TaskAiAdjustmentProposal } from "./lib/taskAiAdjustmentTypes";
import { applyCurrentTaskCriteria, applySavedTaskCriteria } from "./lib/taskCriteriaEditing";
import { applySavedTaskEffort, getWorkspaceEffortLeaves } from "./lib/taskEffortEditing";
import type { TaskEffortEstimate } from "./lib/taskEffort";
import { buildPersonalWorkbenchModel, type PersonalWorkbenchEvidence } from "./lib/personalWorkbench";
import { Button } from "./components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogTitle } from "./components/ui/dialog";

type Theme = "light" | "dark";
type ParticipantInvitationStatuses = Record<string, "accepted" | "pending">;

const localAiStorageKey = "agentdoor-local-ai-connected";
const tagStorageKey = "agentdoor-tags";
const legacyTagGroupsStorageKey = "agentdoor-tag-groups";
const workspaceNodesStorageKey = "agentdoor-workspace-nodes";
const workspaceScenarioVersionKey = "agentdoor-workspace-scenario-version";
const taskActivityStorageKey = "agentdoor-task-activity";
const taskDetailSeedsStorageKey = "agentdoor-task-detail-seeds";
const taskOwnerProposalsStorageKey = "agentdoor-task-owner-proposals";
const taskParticipantInvitationsStorageKey = "agentdoor-task-participant-invitations";
const currentUserId = "周岚";

const loadStoredValue = <T,>(key: string, fallback: T): T => {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) as T : fallback;
  } catch {
    return fallback;
  }
};

const loadStoredText = (key: string): string | null => {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
};

const persistStoredValue = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // 本地存储不可用时保持内存态可用，下次加载会重新尝试迁移。
  }
};

const persistStoredText = (key: string, value: string) => {
  try {
    localStorage.setItem(key, value);
  } catch {
    // 配额或权限限制不应阻断当前会话。
  }
};

const focusPrimaryHeadingAfterNavigation = (target: "auto" | "list" | "detail" | "home" | "creation" = "auto") => {
  window.requestAnimationFrame(() => {
    // The desktop index stays visible; retain its focus for successive selections.
    if (target === "detail" && window.matchMedia("(min-width: 901px)").matches && document.activeElement?.closest(".task-workspace-row")) return;
    const selector = target === "list" ? "#task-workspace-list-heading" : target === "detail" ? ".task-workspace-detail h1" : target === "home" ? "#personal-workbench-heading" : target === "creation" ? ".task-workspace-creation h1" : ".main-content h1";
    const heading = [...document.querySelectorAll<HTMLElement>(selector)].find((element) => element.getClientRects().length > 0);
    if (!heading) return;
    heading.tabIndex = -1;
    heading.focus({ preventScroll: true });
  });
};

const toTaskRelationSummary = (task: TaskNode): TaskRelationSummary => ({
  completionCriteria: task.completionCriteria,
  proposedOwnerId: task.proposedOwnerId,
  dependsOnTaskIds: task.dependsOnTaskIds,
  dueAt: task.dueAt && task.dueAt !== "—" ? task.dueAt : "未设置截止时间",
  goal: task.goal?.trim() || "暂未填写任务目标。",
  iconName: task.iconName,
  iconTone: task.iconTone,
  id: task.id,
  labels: task.labels,
  owner: task.ownerId,
  status: task.status,
  title: task.name,
  updatedAt: task.updatedAt,
});

const formatDateLabel = (value: string) => {
  if (!value) return "待确认";
  const date = new Date(`${value}T12:00:00`);
  return `${date.getMonth() + 1} 月 ${date.getDate()} 日`;
};

const formatPeriodLabel = (startDate: string, endDate: string) => !startDate || startDate === endDate
  ? formatDateLabel(endDate)
  : `${formatDateLabel(startDate)} — ${formatDateLabel(endDate)}`;

const taskDateValue = (value?: string): string | null => {
  if (!value || value === "—" || value.includes("未设置") || value.includes("待排期")) return null;
  const iso = value.match(/^(\d{4}-\d{2}-\d{2})/);
  if (iso) return iso[1];
  const date = new Date();
  const monthDay = value.match(/(\d+)\s*月\s*(\d+)\s*日/);
  if (monthDay) return `${date.getFullYear()}-${monthDay[1].padStart(2, "0")}-${monthDay[2].padStart(2, "0")}`;
  if (value.includes("今天")) return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  return value;
};

function App() {
  const [taskStorageRecoveryError, setTaskStorageRecoveryError] = useState("");
  const [theme, setTheme] = useState<Theme>(() => (loadStoredText("agentdoor-theme") as Theme) || "light");
  const [initialScenarioState] = useState(() => {
    return resolveWorkspaceScenarioReset({
      storedVersion: loadStoredText(workspaceScenarioVersionKey),
      storedWorkspaceNodes: loadStoredValue<unknown>(workspaceNodesStorageKey, initialWorkspaceNodes),
      storedTags: loadStoredValue<unknown>(tagStorageKey, loadStoredValue<unknown>(legacyTagGroupsStorageKey, initialTags)),
    });
  });
  const [latestLegacyTask, setLatestLegacyTask] = useState<LegacyTaskSnapshot | null>(() => initialScenarioState.didReset ? null : loadLatestLegacyTaskSnapshot());
  const [legacyTaskSnapshots, setLegacyTaskSnapshots] = useState<Record<string, LegacyTaskSnapshot>>(() => initialScenarioState.didReset ? {} : loadLegacyTaskSnapshots());
  const [legacyTaskSnapshotsDirty, setLegacyTaskSnapshotsDirty] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [workspaceNodes, setWorkspaceNodes] = useState<WorkspaceNode[]>(initialScenarioState.workspaceNodes);
  const workspaceNodesRef = useRef(workspaceNodes);
  const [taskActivityStore, setTaskActivityStore] = useState<TaskActivityStore>(() => parseTaskActivityStore(loadStoredValue<unknown>(taskActivityStorageKey, {})));
  const [taskDetailSeedNodes, setTaskDetailSeedNodes] = useState<TaskNode[]>(() => {
    const stored = loadStoredValue<unknown>(taskDetailSeedsStorageKey, []);
    const seeds = new Map(normalizeWorkspaceNodes(Array.isArray(stored) ? stored : [])
      .filter((node): node is TaskNode => node.kind === "task")
      .map((node) => [node.id, node]));
    initialScenarioState.workspaceNodes.forEach((node) => {
      if (node.kind === "task" && !seeds.has(node.id)) seeds.set(node.id, { ...node });
    });
    return [...seeds.values()];
  });
  const taskDetailSeedNodesRef = useRef(taskDetailSeedNodes);
  const [tagDefinitions, setTagDefinitions] = useState<TagDefinition[]>(initialScenarioState.tags);
  const [personalCenterState, setPersonalCenterState] = useState<PersonalCenterState>(() => loadPersonalCenterState());
  const [activeTeamId, setActiveTeamId] = useState(() => personalCenterState.teams[0]?.id ?? "");
  const [personalInfoOpen, setPersonalInfoOpen] = useState(false);
  const [personalCenterModule, setPersonalCenterModule] = useState<PersonalCenterModule>("profile");
  const currentUserName = personalCenterState.profile.name;
  const collaborationMembers = useMemo(() => creatorCommerceMembers.map((member) => member.id === currentUserId ? { ...member, name: personalCenterState.profile.name, email: personalCenterState.profile.email, role: personalCenterState.profile.title } : member), [personalCenterState.profile]);
  const [activeSection, setActiveSection] = useState<PrimarySection>("home");
  const [conversationRevision, setConversationRevision] = useState(0);
  const [creationSessionOpen, setCreationSessionOpen] = useState(false);
  const creationSessionCompleted = useRef(false);
  const [workbenchAsOf, setWorkbenchAsOf] = useState(() => new Date().toISOString());
  const [cliConnectionOpen, setCliConnectionOpen] = useState(false);
  const [taskQuery, setTaskQuery] = useState("");
  const [taskFilters, setTaskFilters] = useState<TaskListFilters>(() => createInitialTaskListFilters(currentUserId));
  const [taskPeriodOverrides, setTaskPeriodOverrides] = useState<Record<string, { end: string; start: string } | null>>({});
  const [taskOwnerProposals, setTaskOwnerProposals] = useState<Record<string, string>>(() => {
    const stored = loadStoredValue<unknown>(taskOwnerProposalsStorageKey, {});
    return stored && typeof stored === "object" && !Array.isArray(stored)
      ? Object.fromEntries(Object.entries(stored).filter((entry): entry is [string, string] => typeof entry[1] === "string" && Boolean(entry[1])))
      : {};
  });
  const [taskParticipantInvitationOverrides, setTaskParticipantInvitationOverrides] = useState<Record<string, ParticipantInvitationStatuses>>(() => {
    const stored = loadStoredValue<unknown>(taskParticipantInvitationsStorageKey, {});
    if (!stored || typeof stored !== "object" || Array.isArray(stored)) return {};
    return Object.fromEntries(Object.entries(stored).flatMap(([taskId, statuses]) => statuses && typeof statuses === "object" && !Array.isArray(statuses)
      ? [[taskId, Object.fromEntries(Object.entries(statuses).filter((entry): entry is [string, "accepted" | "pending"] => entry[1] === "accepted" || entry[1] === "pending"))]]
      : []));
  });
  const [taskAttentionTarget, setTaskAttentionTarget] = useState<TaskAttentionTarget | null>(null);
  const [subtaskDeleteTarget, setSubtaskDeleteTarget] = useState<{ taskId: string; parentTaskId: string; signature: string } | null>(null);
  const [subtaskDeleteError, setSubtaskDeleteError] = useState("");
  const deletingSubtask = useRef(false);
  const subtaskDeleteReturnFocus = useRef<HTMLElement | null>(null);
  const subtaskDeleteCancel = useRef<HTMLButtonElement>(null);
  const subtaskDeletion = useMemo(() => {
    if (!subtaskDeleteTarget) return { preview: null, error: "" };
    try { return { preview: getSubtaskDeletionPreview(workspaceNodes, subtaskDeleteTarget.parentTaskId, subtaskDeleteTarget.taskId), error: "" }; }
    catch (error) { return { preview: null, error: error instanceof Error ? error.message : "无法核对删除范围，请关闭后重试。" }; }
  }, [workspaceNodes, subtaskDeleteTarget]);

  const changePersonalInfoOpen = (open: boolean) => {
    setPersonalInfoOpen(open);
    if (open) return;
    window.requestAnimationFrame(() => {
      document.querySelector<HTMLElement>("#workspace-account-trigger")?.focus();
    });
  };

  const showTaskList = () => {
    window.history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
    setSelectedTaskId(null);
    setActiveSection("tasks");
    focusPrimaryHeadingAfterNavigation("list");
  };

  const openTask = (taskId: string) => {
    if (!workspaceNodesRef.current.some(node => node.kind === "task" && node.id === taskId)) return;
    setSelectedTaskId(taskId);
    setActiveSection("tasks");
    focusPrimaryHeadingAfterNavigation("detail");
  };

  const startNewTaskConversation = () => {
    window.history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
    if (!creationSessionOpen || creationSessionCompleted.current) {
      setConversationRevision((revision) => revision + 1);
      setCreationSessionOpen(true);
      creationSessionCompleted.current = false;
    }
    setActiveSection("conversation");
    focusPrimaryHeadingAfterNavigation("creation");
  };

  const showPrimarySection = (section: "home" | "tasks") => {
    setActiveSection(section);
    setTaskAttentionTarget(null);
    if (section === "home") setWorkbenchAsOf(new Date().toISOString());
    focusPrimaryHeadingAfterNavigation(section === "tasks" ? selectedTaskId ? "detail" : "list" : "home");
  };

  const openWorkbenchEvidence = (evidence: PersonalWorkbenchEvidence) => {
    setTaskAttentionTarget(evidence.kind === "task" ? null : { kind: evidence.kind, targetId: evidence.id ?? evidence.taskId });
    openTask(evidence.taskId);
  };

  useEffect(() => {
    if (activeSection !== "home") return;
    const timer = window.setInterval(() => setWorkbenchAsOf(new Date().toISOString()), 60_000);
    return () => window.clearInterval(timer);
  }, [activeSection]);

  useEffect(() => {
    try {
      commitWorkspaceScenarioReset(localStorage, initialScenarioState, {
        legacyKeys: [
          legacyTagGroupsStorageKey,
          "agentdoor-created-task",
          "agentdoor-created-tasks",
          "agentdoor-tag-catalog-version",
          "agentdoor-workspace-mock-version",
        ],
        tagsKey: tagStorageKey,
        versionKey: workspaceScenarioVersionKey,
        workspaceNodesKey: workspaceNodesStorageKey,
      });
    } catch {
      // 浏览器禁止访问 localStorage 时仍允许以内存态使用应用。
    }
  }, [initialScenarioState]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    persistStoredText("agentdoor-theme", theme);
  }, [theme]);

  useEffect(() => {
    if (taskStorageRecoveryError) return;
    workspaceNodesRef.current = workspaceNodes;
    persistStoredValue(workspaceNodesStorageKey, workspaceNodes);
  }, [workspaceNodes, taskStorageRecoveryError]);
  useEffect(() => persistStoredValue(tagStorageKey, tagDefinitions), [tagDefinitions]);
  useEffect(() => { if (!taskStorageRecoveryError) persistStoredValue(taskActivityStorageKey, taskActivityStore); }, [taskActivityStore, taskStorageRecoveryError]);
  useEffect(() => { if (!taskStorageRecoveryError) persistStoredValue(taskDetailSeedsStorageKey, taskDetailSeedNodes); }, [taskDetailSeedNodes, taskStorageRecoveryError]);
  useEffect(() => { if (!taskStorageRecoveryError) persistStoredValue(taskOwnerProposalsStorageKey, taskOwnerProposals); }, [taskOwnerProposals, taskStorageRecoveryError]);
  useEffect(() => persistStoredValue(taskParticipantInvitationsStorageKey, taskParticipantInvitationOverrides), [taskParticipantInvitationOverrides]);
  useEffect(() => {
    if (!legacyTaskSnapshotsDirty || taskStorageRecoveryError) return;
    try {
      persistLegacyTaskSnapshots(legacyTaskSnapshots);
    } catch {
      // 存储不可用时仍保留当前内存态编辑。
    }
  }, [legacyTaskSnapshots, legacyTaskSnapshotsDirty, taskStorageRecoveryError]);

  const updateLegacyTaskSnapshot = (taskId: string, changes: Partial<LegacyTaskSnapshot>) => {
    setLegacyTaskSnapshots((current) => current[taskId]
      ? { ...current, [taskId]: { ...current[taskId], ...changes } }
      : current);
    setLegacyTaskSnapshotsDirty(true);
  };

  const preserveTaskDetailSeed = (task: TaskNode) => {
    if (taskDetailSeedNodesRef.current.some((seed) => seed.id === task.id)) return;
    const next = [...taskDetailSeedNodesRef.current, { ...task }];
    taskDetailSeedNodesRef.current = next;
    setTaskDetailSeedNodes(next);
  };

  const appendActivityForTask = (taskId: string, activity: TaskActivityMock) => {
    const task = workspaceNodesRef.current.find((node): node is TaskNode => node.kind === "task" && node.id === taskId);
    if (!task) return;
    preserveTaskDetailSeed(task);
    setTaskActivityStore((current) => appendTaskActivity(current, taskId, activity));
  };

  const changeTaskFields = (taskId: string, patch: Partial<TaskNode>, type: TaskActivityType, message: string, changes: TaskActivityChange[]) => {
    const task = workspaceNodesRef.current.find((node): node is TaskNode => node.kind === "task" && node.id === taskId);
    if (!task) return;
    const activity = createTaskChangeActivity({ author: currentUserName, type, message, changes });
    if (!activity) return;
    preserveTaskDetailSeed(task);
    const next = workspaceNodesRef.current.map((node) => node.id === taskId && node.kind === "task" ? { ...node, ...patch, updatedAt: "刚刚" } : node);
    workspaceNodesRef.current = next;
    setWorkspaceNodes(next);
    appendActivityForTask(taskId, activity);
  };

  const changeTaskStatus = (taskId: string, status: TaskNode["status"]) => {
    const task = workspaceNodesRef.current.find((node): node is TaskNode => node.kind === "task" && node.id === taskId);
    if (!task || task.status === status) return;
    const activity = createTaskChangeActivity({ author: currentUserName, type: "status-change", message: "更新任务状态", changes: [{ label: "状态", before: task.status, after: status }] });
    if (!activity) return;
    preserveTaskDetailSeed(task);
    const next = updateWorkspaceTaskStatus(workspaceNodesRef.current, taskId, status);
    workspaceNodesRef.current = next;
    setWorkspaceNodes(next);
    appendActivityForTask(taskId, activity);
  };

  const createTaskPlanFromConversation = (draft: TaskPlanDraft, parentTaskId?: string) => {
    const result = createWorkspaceTasksFromDraft(workspaceNodesRef.current, draft, { parentTaskId, currentUserId });
    // Do not report a successful local creation if storage rejected the write.
    try {
      localStorage.setItem(workspaceNodesStorageKey, JSON.stringify(result.nodes));
    } catch {
      throw new Error("当前浏览器无法保存任务。请检查存储空间或隐私设置，草稿已保留。");
    }
    workspaceNodesRef.current = result.nodes;
    setWorkspaceNodes(result.nodes);
    creationSessionCompleted.current = true;
    return {
      createdCount: result.createdNodes.length,
      mainTaskId: result.mainTaskId,
      taskTitles: result.createdNodes.map((task) => task.name),
    };
  };

  const createSubtask = (draft: NewSubtaskDraft) => {
    if (taskStorageRecoveryError) throw new Error(taskStorageRecoveryError);
    if (!selectedTaskId) throw new Error("请先选择父任务。");
    const next = addWorkspaceSubtask(workspaceNodesRef.current, selectedTaskId, draft, { currentUserId, author: currentUserName });
    const nextActivities = next.activity ? appendTaskActivity(taskActivityStore, selectedTaskId, next.activity) : taskActivityStore;
    const nextSeeds = taskDetailSeedNodesRef.current.some(node => node.id === next.parent.id)
      ? taskDetailSeedNodesRef.current : [...taskDetailSeedNodesRef.current, { ...next.parent }];
    try {
      commitTaskAiStorage(localStorage, [
        [workspaceNodesStorageKey, JSON.stringify(next.nodes)],
        [taskActivityStorageKey, JSON.stringify(nextActivities)],
        [taskDetailSeedsStorageKey, JSON.stringify(nextSeeds)],
      ]);
    } catch (caught) {
      try { recoverTaskAiStorage(localStorage); }
      catch (error) { setTaskStorageRecoveryError(error instanceof Error ? error.message : "本地记录需要恢复，请暂时停止编辑。"); }
      throw caught;
    }
    workspaceNodesRef.current = next.nodes;
    taskDetailSeedNodesRef.current = nextSeeds;
    setWorkspaceNodes(next.nodes);
    setTaskActivityStore(nextActivities);
    setTaskDetailSeedNodes(nextSeeds);
  };

  const requestDeleteSubtask = (taskId: string, returnFocus?: HTMLElement | null) => {
    if (!selectedTaskId) return;
    subtaskDeleteReturnFocus.current = returnFocus ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null);
    deletingSubtask.current = false;
    setSubtaskDeleteError("");
    try {
      const preview = getSubtaskDeletionPreview(workspaceNodesRef.current, selectedTaskId, taskId);
      setSubtaskDeleteTarget({ taskId, parentTaskId: selectedTaskId, signature: preview.signature });
    } catch (error) {
      setSubtaskDeleteTarget({ taskId, parentTaskId: selectedTaskId, signature: "" });
      setSubtaskDeleteError(error instanceof Error ? error.message : "无法核对删除范围，请关闭后重试。");
    }
  };

  const confirmDeleteSubtask = () => {
    if (!subtaskDeleteTarget || deletingSubtask.current) return;
    if (taskStorageRecoveryError) { setSubtaskDeleteError(taskStorageRecoveryError); return; }
    deletingSubtask.current = true;
    try {
      const next = deleteWorkspaceSubtask({
        nodes: workspaceNodesRef.current, activities: taskActivityStore, detailSeeds: taskDetailSeedNodesRef.current,
        ownerProposals: taskOwnerProposals, participantInvitations: taskParticipantInvitationOverrides,
        periodOverrides: taskPeriodOverrides, legacySnapshots: legacyTaskSnapshots, latestLegacySnapshot: latestLegacyTask,
      }, subtaskDeleteTarget.parentTaskId, subtaskDeleteTarget.taskId, subtaskDeleteTarget.signature, currentUserName);
      try { commitTaskAiStorage(localStorage, getSubtaskDeletionWrites(next)); }
      catch (caught) {
        try { recoverTaskAiStorage(localStorage); }
        catch (error) { setTaskStorageRecoveryError(error instanceof Error ? error.message : "本地记录需要恢复，请暂时停止编辑。"); }
        throw caught;
      }
      clearTaskFileDraftSessions(next.deletedTaskIds);
      workspaceNodesRef.current = next.nodes;
      taskDetailSeedNodesRef.current = next.detailSeeds;
      setWorkspaceNodes(next.nodes);
      setTaskActivityStore(next.activities);
      setTaskDetailSeedNodes(next.detailSeeds);
      setTaskOwnerProposals(next.ownerProposals);
      setTaskParticipantInvitationOverrides(next.participantInvitations);
      setTaskPeriodOverrides(next.periodOverrides);
      setLegacyTaskSnapshots(next.legacySnapshots);
      setLatestLegacyTask(next.latestLegacySnapshot);
      setLegacyTaskSnapshotsDirty(true);
      setSubtaskDeleteTarget(null);
      setSubtaskDeleteError("");
      setTaskAttentionTarget({ kind: "subtasks", targetId: next.parentTaskId });
      openTask(next.parentTaskId);
    } catch (error) {
      deletingSubtask.current = false;
      setSubtaskDeleteError(error instanceof Error ? error.message : "删除未完成，任务已保留，请重试。");
      try {
        const preview = getSubtaskDeletionPreview(workspaceNodesRef.current, subtaskDeleteTarget.parentTaskId, subtaskDeleteTarget.taskId);
        if (preview.signature !== subtaskDeleteTarget.signature) setSubtaskDeleteTarget({ ...subtaskDeleteTarget, signature: preview.signature });
      } catch { /* Keep the dialog open without a destructive action if the target disappeared. */ }
    }
  };

  const selectedTreeTask = workspaceNodes.find((node) => node.kind === "task" && node.id === selectedTaskId);
  const selectedParentTask = selectedTreeTask?.kind === "task" && selectedTreeTask.parentTaskId
    ? workspaceNodes.find((node): node is TaskNode => node.kind === "task" && node.id === selectedTreeTask.parentTaskId)
    : undefined;
  const selectedTaskPath = selectedTreeTask ? [
    { id: workspaceRootId, label: "任务" },
    ...(selectedParentTask ? [{ id: selectedParentTask.id, label: selectedParentTask.name }] : []),
    { id: selectedTreeTask.id, label: selectedTreeTask.name },
  ] : [];
  const selectedTaskMock = selectedTaskId ? taskDetailMocks[selectedTaskId as TaskDetailId] : undefined;
  const selectedLegacyTask = selectedTaskId ? legacyTaskSnapshots[selectedTaskId] : undefined;
  // 示例原文只使用首次快照；当前字段编辑不能重写已有事件、提交或文件名称。
  const selectedTaskSeedNode = taskDetailSeedNodes.find((node) => node.id === selectedTaskId);
  const customTaskDetail: TaskDetailMock | undefined = selectedTaskId && selectedTreeTask?.kind === "task" && !selectedTaskMock ? !selectedLegacyTask ? createWorkspaceTaskDetail(selectedTaskSeedNode ?? selectedTreeTask) : {
    activities: [{ id: `${selectedTaskId}-created`, author: "AgentDoor AI", message: "此任务来自已停用的旧创建流程；原有文件、成员与父子任务关系已保留。", time: "历史记录", type: "ai-insight" }],
    commits: [],
    due: selectedLegacyTask.plannedStartOn && selectedLegacyTask.plannedEndOn ? formatPeriodLabel(selectedLegacyTask.plannedStartOn, selectedLegacyTask.plannedEndOn) : selectedTreeTask.dueAt ?? "—",
    files: selectedLegacyTask.contextIds.map((sourceId) => {
      const source = legacyTaskSources.find((item) => item.id === sourceId);
      return {
        content: source?.snippet ?? "这是旧任务记录中保留的资料引用。",
        format: source?.type === "data" ? "DATA" : source?.type === "task" ? "TASK" : source?.type === "change" ? "PATCH" : source?.title.toLowerCase().endsWith(".pdf") ? "PDF" : "DOCX",
        id: `${selectedTaskId}-${sourceId}`,
        kind: "file" as const,
        name: source?.title ?? sourceId,
        parentId: null,
        updatedAt: "创建时引用",
      };
    }),
    goal: selectedTreeTask.goal ?? selectedLegacyTask.goal,
    iconName: selectedTreeTask.iconName,
    iconTone: selectedTreeTask.iconTone,
    owner: selectedTreeTask.ownerId,
    participantInvitationStatus: Object.fromEntries(selectedLegacyTask.participants.map((id) => [id, "pending" as const])),
    participants: selectedLegacyTask.participants.filter((id) => id !== selectedTreeTask.ownerId),
    status: selectedTreeTask.status,
    summary: "任务已保留；当前继续围绕目标、文件和活动推进。",
    title: selectedTreeTask.name,
  } : undefined;
  const selectedTaskDetailBase: TaskDetailMock | undefined = customTaskDetail ?? selectedTaskMock;
  const selectedTaskPeriodOverride = selectedTaskId ? taskPeriodOverrides[selectedTaskId] : undefined;
  const selectedParticipants = selectedTaskDetailBase && selectedTreeTask?.kind === "task"
    ? (selectedLegacyTask?.participants ?? selectedTreeTask.participantIds ?? selectedTaskDetailBase.participants).filter((id) => id !== selectedTreeTask.ownerId)
    : selectedTaskDetailBase?.participants ?? [];
  const selectedParticipantInvitationStatus: ParticipantInvitationStatuses = Object.fromEntries(selectedParticipants.map((id) => [id,
    (selectedTaskId ? taskParticipantInvitationOverrides[selectedTaskId]?.[id] : undefined)
      ?? selectedTaskDetailBase?.participantInvitationStatus?.[id]
      ?? "pending",
  ]));
  const seedActivityIds = new Set(selectedTaskDetailBase?.activities.map((activity) => activity.id));
  const selectedTaskDetail = selectedTaskDetailBase && selectedTaskId && selectedTreeTask?.kind === "task" ? {
    ...selectedTaskDetailBase,
    completionCriteria: selectedTreeTask.completionCriteria,
    executionTips: selectedTreeTask.executionTips ?? selectedTaskDetailBase.executionTips,
    activities: [
      ...(taskActivityStore[selectedTaskId] ?? []).filter((activity) => !seedActivityIds.has(activity.id)),
      ...selectedTaskDetailBase.activities,
    ],
    due: selectedTaskPeriodOverride === null ? "—" : selectedTaskPeriodOverride ? formatPeriodLabel(selectedTaskPeriodOverride.start, selectedTaskPeriodOverride.end) : selectedTreeTask.dueAt ?? selectedTaskDetailBase.due,
    goal: selectedParentTask ? getTaskDefinitionGoal(workspaceNodes, selectedTreeTask) : selectedTreeTask.goal ?? selectedTaskDetailBase.goal,
    iconName: selectedTreeTask.iconName,
    iconTone: selectedTreeTask.iconTone,
    owner: selectedTreeTask.ownerId,
    participantInvitationStatus: selectedParticipantInvitationStatus,
    participants: selectedParticipants,
    status: selectedTreeTask.status,
    title: selectedTreeTask.name,
  } : undefined;
  const selectedChildTasks = selectedTaskId ? workspaceNodes
    .filter((node): node is TaskNode => node.kind === "task" && node.parentTaskId === selectedTaskId)
    .map(node => ({ ...toTaskRelationSummary(node), proposedOwnerId: legacyTaskSnapshots[node.id]?.proposedOwnerId ?? taskOwnerProposals[node.id] ?? node.proposedOwnerId })) : [];
  const selectedDependencyTaskIds = selectedTreeTask?.kind === "task" ? selectedTreeTask.dependsOnTaskIds ?? [] : [];
  const selectedDependencyTasks = workspaceNodes
    .filter((node): node is TaskNode => node.kind === "task" && selectedDependencyTaskIds.includes(node.id))
    .map(toTaskRelationSummary);
  const taskCreationExistingTasks = workspaceNodes
    .filter((node): node is TaskNode => node.kind === "task")
    .map(({ id, name, ownerId, status, goal, dueAt, labels, parentTaskId, plannedStartOn, plannedEndOn, iconName, iconTone, updatedAt }) => ({
      id,
      name,
      ownerId,
      status,
      goal,
      dueAt,
      labels,
      parentTaskId,
      plannedStartOn,
      plannedEndOn,
      iconName,
      iconTone,
      updatedAt,
      childTaskNames: workspaceNodes
        .filter((node): node is TaskNode => node.kind === "task" && node.parentTaskId === id)
        .map((node) => node.name),
    }));

  const getSelectedTask = () => workspaceNodesRef.current.find((node): node is TaskNode => node.kind === "task" && node.id === selectedTaskId);

  const changeTaskTitle = (name: string) => {
    const task = getSelectedTask();
    if (task) changeTaskFields(task.id, { name }, "title-change", "修改任务名称", [{ label: "任务名称", before: task.name || null, after: name || null }]);
  };

  const changeTaskGoal = (goal: string) => {
    const task = getSelectedTask();
    if (task) changeTaskFields(task.id, { goal }, "goal-change", "修改任务目标", [{ label: "任务目标", before: task.goal ?? selectedTaskDetail?.goal ?? null, after: goal || null }]);
  };

  const changeTaskAppearance = (appearance: { iconName: TaskIconName; iconTone: TaskIconTone }) => {
    const task = getSelectedTask();
    if (!task) return;
    const iconLabel = (value: TaskIconName) => taskIconOptions.find((option) => option.value === value)?.label ?? value;
    const toneLabel = (value: TaskIconTone) => taskIconToneOptions.find((option) => option.value === value)?.label ?? value;
    changeTaskFields(task.id, appearance, "appearance-change", "修改任务外观", [
      { label: "图标", before: iconLabel(task.iconName ?? "list-todo"), after: iconLabel(appearance.iconName) },
      { label: "背景色", before: toneLabel(task.iconTone ?? "neutral"), after: toneLabel(appearance.iconTone) },
    ]);
  };

  const changeTaskTags = (taskId: string, labels: string[]) => {
    const task = workspaceNodesRef.current.find((node): node is TaskNode => node.kind === "task" && node.id === taskId);
    if (!task) return;
    const tagsValue = (values: string[]) => [...new Set(values)].sort().join("、") || null;
    changeTaskFields(taskId, { labels }, "tags-change", "修改任务标签", [{ label: "标签", before: tagsValue(task.labels ?? []), after: tagsValue(labels) }]);
  };

  const changeOwner = (ownerIds: string[]) => {
    const task = getSelectedTask();
    if (!task) return;
    const ownerId = ownerIds[0] ?? "";
    changeTaskFields(task.id, { ownerId }, "owner-change", ownerId ? "修改任务负责人" : "清空任务负责人", [{ label: "负责人", before: task.ownerId || null, after: ownerId || null }]);
  };

  const changeOwnerProposal = (ownerId?: string) => {
    const task = getSelectedTask();
    if (!task) return;
    const previous = selectedLegacyTask?.proposedOwnerId ?? taskOwnerProposals[task.id] ?? task.proposedOwnerId;
    const activity = createTaskChangeActivity({ author: currentUserName, type: "owner-proposal", message: ownerId ? "发起负责人变更邀请（待接受）" : "撤回负责人变更邀请", changes: [{
      label: "负责人变更邀请",
      before: previous ? `${previous}（待接受）` : null,
      after: ownerId ? `${ownerId}（待接受）` : null,
    }] });
    if (!activity) return;
    setTaskOwnerProposals((current) => {
      const next = { ...current };
      if (ownerId) next[task.id] = ownerId;
      else delete next[task.id];
      return next;
    });
    const next = workspaceNodesRef.current.map(node => node.id === task.id ? { ...task, proposedOwnerId: ownerId } : node);
    workspaceNodesRef.current = next;
    setWorkspaceNodes(next);
    if (selectedLegacyTask) updateLegacyTaskSnapshot(task.id, {
      ownerAssignmentStatus: ownerId ? "pending-acceptance" : "confirmed",
      proposedOwnerId: ownerId,
    });
    appendActivityForTask(task.id, activity);
  };

  const changeParticipants = (participants: string[]) => {
    const task = getSelectedTask();
    if (!task) return;
    const previous = (selectedLegacyTask?.participants ?? task.participantIds ?? selectedTaskDetail?.participants ?? []).filter((id) => id !== task.ownerId);
    const next = [...new Set(participants.filter((id) => id !== task.ownerId))];
    const added = next.filter((id) => !previous.includes(id));
    const removed = previous.filter((id) => !next.includes(id));
    if (!added.length && !removed.length) return;
    const changes: TaskActivityChange[] = [
      ...added.map((id) => ({ label: "新增参与人（待接受）", before: null, after: id })),
      ...removed.map((id) => ({ label: "移除参与人", before: id, after: null })),
    ];
    changeTaskFields(task.id, selectedLegacyTask ? {} : { participantIds: next }, "participants-change", "更新任务参与人", changes);
    if (selectedLegacyTask) updateLegacyTaskSnapshot(task.id, { participants: next });
    const statuses: ParticipantInvitationStatuses = Object.fromEntries(next.map((id) => [id, added.includes(id) ? "pending" : selectedParticipantInvitationStatus[id] ?? "pending"]));
    setTaskParticipantInvitationOverrides((current) => ({ ...current, [task.id]: statuses }));
  };

  const changeTaskPeriod = (range: TaskDateRange | null) => {
    const task = getSelectedTask();
    if (!task) return;
    const previousStart = taskDateValue(selectedTaskPeriodOverride === undefined ? task.plannedStartOn ?? selectedLegacyTask?.plannedStartOn : selectedTaskPeriodOverride?.start);
    const previousEnd = taskDateValue(selectedTaskPeriodOverride === undefined ? task.plannedEndOn ?? selectedLegacyTask?.plannedEndOn ?? task.dueAt ?? selectedTaskDetail?.due : selectedTaskPeriodOverride?.end);
    const nextStart = range?.start || null;
    const nextEnd = range?.end || null;
    if (previousStart === nextStart && previousEnd === nextEnd) return;
    changeTaskFields(task.id, { dueAt: range ? formatDateLabel(range.end) : "—", plannedEndOn: range?.end, plannedStartOn: range?.start }, "schedule-change", "修改任务时间", [
      { label: "开始时间", before: previousStart, after: nextStart },
      { label: "截止时间", before: previousEnd, after: nextEnd },
    ]);
    setTaskPeriodOverrides((current) => ({ ...current, [task.id]: range }));
    if (selectedLegacyTask) updateLegacyTaskSnapshot(task.id, { plannedEndOn: range?.end, plannedStartOn: range?.start });
  };

  const effectiveAiNodes = (nodes: WorkspaceNode[]) => nodes.map(node => {
    if (node.kind !== "task") return node;
    const legacy = legacyTaskSnapshots[node.id];
    const period = taskPeriodOverrides[node.id];
    return {
      ...node,
      ...(legacy ? { participantIds: legacy.participants, plannedStartOn: node.plannedStartOn ?? legacy.plannedStartOn, plannedEndOn: node.plannedEndOn ?? legacy.plannedEndOn } : {}),
      ...(period !== undefined ? { plannedStartOn: period?.start, plannedEndOn: period?.end, dueAt: period ? formatPeriodLabel(period.start, period.end) : "—" } : {}),
    };
  });
  const effectiveAiProposals = {
    ...taskOwnerProposals,
    ...Object.fromEntries(Object.values(legacyTaskSnapshots).filter(task => task.proposedOwnerId).map(task => [task.id, task.proposedOwnerId!])),
  };
  const selectedAiAdjustmentContext = selectedTaskId ? createSavedTaskAiContext(effectiveAiNodes(workspaceNodes), selectedTaskId, collaborationMembers, currentUserId, effectiveAiProposals) : null;
  const selectedEffortTasks = selectedTaskId ? getWorkspaceEffortLeaves(workspaceNodes, selectedTaskId) : [];

  const personalWorkbenchModel = useMemo(() => {
    const tasks = effectiveAiNodes(workspaceNodes)
      .filter((node): node is TaskNode => node.kind === "task")
      .map(task => ({ ...task, proposedOwnerId: legacyTaskSnapshots[task.id]?.proposedOwnerId ?? taskOwnerProposals[task.id] ?? task.proposedOwnerId }));
    const seeds = new Map(taskDetailSeedNodes.map(task => [task.id, task]));
    const detailsByTaskId = Object.fromEntries(tasks.map(task => {
      const base = taskDetailMocks[task.id as TaskDetailId] ?? createWorkspaceTaskDetail(seeds.get(task.id) ?? task);
      const seedIds = new Set(base.activities.map(activity => activity.id));
      return [task.id, {
        ...base,
        activities: [...(taskActivityStore[task.id] ?? []).filter(activity => !seedIds.has(activity.id)), ...base.activities],
      }];
    }));
    return buildPersonalWorkbenchModel({ tasks, currentUserId, asOf: workbenchAsOf, detailsByTaskId });
  }, [workspaceNodes, legacyTaskSnapshots, taskPeriodOverrides, taskOwnerProposals, taskDetailSeedNodes, taskActivityStore, workbenchAsOf]);

  const saveTaskEffort = (estimate: TaskEffortEstimate, expectedSignature: string) => {
    if (taskStorageRecoveryError) throw new Error(taskStorageRecoveryError);
    if (!selectedTaskId) throw new Error("请先选择任务。");
    const next = applySavedTaskEffort(workspaceNodesRef.current, selectedTaskId, estimate, expectedSignature, currentUserName);
    if (!next.activity) return;
    const nextActivities = appendTaskActivity(taskActivityStore, selectedTaskId, next.activity);
    const nextSeeds = taskDetailSeedNodesRef.current.some(node => node.id === selectedTaskId)
      ? taskDetailSeedNodesRef.current : [...taskDetailSeedNodesRef.current, { ...next.original }];
    try {
      commitTaskAiStorage(localStorage, [
        [workspaceNodesStorageKey, JSON.stringify(next.nodes)],
        [taskActivityStorageKey, JSON.stringify(nextActivities)],
        [taskDetailSeedsStorageKey, JSON.stringify(nextSeeds)],
      ]);
    } catch (caught) {
      try { recoverTaskAiStorage(localStorage); }
      catch (error) { setTaskStorageRecoveryError(error instanceof Error ? error.message : "本地记录需要恢复。"); }
      throw caught;
    }
    workspaceNodesRef.current = next.nodes;
    taskDetailSeedNodesRef.current = nextSeeds;
    setWorkspaceNodes(next.nodes);
    setTaskActivityStore(nextActivities);
    setTaskDetailSeedNodes(nextSeeds);
  };

  const persistTaskCriteria = (next: ReturnType<typeof applyCurrentTaskCriteria>) => {
    if (!next.activity) return;
    const taskId = next.original.id;
    const nextActivities = appendTaskActivity(taskActivityStore, taskId, next.activity);
    const nextSeeds = taskDetailSeedNodesRef.current.some(node => node.id === taskId)
      ? taskDetailSeedNodesRef.current : [...taskDetailSeedNodesRef.current, { ...next.original }];
    try {
      commitTaskAiStorage(localStorage, [
        [workspaceNodesStorageKey, JSON.stringify(next.nodes)],
        [taskActivityStorageKey, JSON.stringify(nextActivities)],
        [taskDetailSeedsStorageKey, JSON.stringify(nextSeeds)],
      ]);
    } catch (caught) {
      try { recoverTaskAiStorage(localStorage); }
      catch (error) { setTaskStorageRecoveryError(error instanceof Error ? error.message : "本地记录需要恢复。"); }
      throw caught;
    }
    workspaceNodesRef.current = next.nodes;
    taskDetailSeedNodesRef.current = nextSeeds;
    setWorkspaceNodes(next.nodes);
    setTaskActivityStore(nextActivities);
    setTaskDetailSeedNodes(nextSeeds);
  };

  const saveSubtaskCriteria = (taskId: string, values: string[], expected: string[]) => {
    if (taskStorageRecoveryError) throw new Error(taskStorageRecoveryError);
    if (!selectedTaskId) throw new Error("请先选择主任务。");
    persistTaskCriteria(applySavedTaskCriteria(workspaceNodesRef.current, selectedTaskId, taskId, expected, values, currentUserName));
  };

  const saveTaskCriteria = (values: string[], expected: string[]) => {
    if (taskStorageRecoveryError) throw new Error(taskStorageRecoveryError);
    if (!selectedTaskId) throw new Error("请先选择任务。");
    persistTaskCriteria(applyCurrentTaskCriteria(workspaceNodesRef.current, selectedTaskId, expected, values, currentUserName));
  };

  const applyTaskAiAdjustment = (proposal: TaskAiAdjustmentProposal) => {
    if (taskStorageRecoveryError) throw new Error(taskStorageRecoveryError);
    if (!selectedTaskId) throw new Error("请先选择要调整的任务。");
    const currentNodes = workspaceNodesRef.current;
    const effectiveNodes = effectiveAiNodes(currentNodes);
    const context = createSavedTaskAiContext(effectiveNodes, selectedTaskId, collaborationMembers, currentUserId, effectiveAiProposals);
    if (!context) throw new Error("任务已不存在，请返回列表。");
    const next = applySavedTaskAiAdjustment(currentNodes, context, proposal, { author: currentUserName, effectiveNodes });
    if (!next.affectedIds.length) return;
    let nextActivities = taskActivityStore;
    for (const [taskId, activities] of Object.entries(next.activities)) for (const activity of activities) nextActivities = appendTaskActivity(nextActivities, taskId, activity);
    const nextSeeds = [...taskDetailSeedNodesRef.current];
    for (const id of next.affectedIds) {
      const original = currentNodes.find((node): node is TaskNode => node.kind === "task" && node.id === id);
      if (original && !nextSeeds.some(seed => seed.id === id)) nextSeeds.push({ ...original });
    }
    const nextProposals = { ...taskOwnerProposals };
    const nextPeriods = { ...taskPeriodOverrides };
    const nextLegacy = { ...legacyTaskSnapshots };
    let legacyChanged = false;
    for (const { taskId, patch } of proposal.updates) {
      if (patch.ownerId) nextProposals[taskId] = patch.ownerId;
      const node = next.nodes.find((item): item is TaskNode => item.kind === "task" && item.id === taskId)!;
      if (patch.endDate !== undefined || patch.startDate !== undefined) {
        delete nextPeriods[taskId];
      }
      if (nextLegacy[taskId]) {
        nextLegacy[taskId] = {
          ...nextLegacy[taskId],
          ...(patch.title !== undefined ? { title: node.name } : {}),
          ...(patch.goal !== undefined ? { goal: node.goal ?? "" } : {}),
          ...(patch.ownerId ? { proposedOwnerId: patch.ownerId, ownerAssignmentStatus: "pending-acceptance" as const } : {}),
          ...(patch.endDate !== undefined || patch.startDate !== undefined ? { plannedStartOn: node.plannedStartOn, plannedEndOn: node.plannedEndOn } : {}),
        };
        legacyChanged = true;
      }
    }
    const writes: Array<[string, string]> = [
      [workspaceNodesStorageKey, JSON.stringify(next.nodes)],
      [taskActivityStorageKey, JSON.stringify(nextActivities)],
      [taskDetailSeedsStorageKey, JSON.stringify(nextSeeds)],
      [taskOwnerProposalsStorageKey, JSON.stringify(nextProposals)],
      ...(legacyChanged ? [["agentdoor-created-tasks", JSON.stringify(nextLegacy)] as [string, string]] : []),
    ];
    try { commitTaskAiStorage(localStorage, writes); }
    catch (caught) {
      try { recoverTaskAiStorage(localStorage); }
      catch (recoveryError) { setTaskStorageRecoveryError(recoveryError instanceof Error ? recoveryError.message : "本地记录需要恢复，暂时停止编辑。"); }
      throw caught;
    }
    workspaceNodesRef.current = next.nodes;
    taskDetailSeedNodesRef.current = nextSeeds;
    setWorkspaceNodes(next.nodes);
    setTaskActivityStore(nextActivities);
    setTaskDetailSeedNodes(nextSeeds);
    setTaskOwnerProposals(nextProposals);
    setTaskPeriodOverrides(nextPeriods);
    if (legacyChanged) { setLegacyTaskSnapshots(nextLegacy); setLegacyTaskSnapshotsDirty(true); }
  };

  return (
    <PersonDirectoryProvider members={collaborationMembers}>
    <div className="app-shell task-workspace-shell">
      <WorkspaceTopbar
        activeTeamId={activeTeamId}
        onOpenPersonalCenter={(module) => { setPersonalCenterModule(module); setPersonalInfoOpen(true); }}
        onOpenTaskInsight={(taskId) => { setTaskAttentionTarget({ kind: "insight", targetId: "latest" }); openTask(taskId); }}
        onTeamChange={setActiveTeamId}
        teams={personalCenterState.teams}
        theme={theme}
        toggleTheme={() => setTheme((current) => current === "light" ? "dark" : "light")}
        userId={currentUserId}
        userProfile={personalCenterState.profile}
      />

      <PersonalCenterModal activeModule={personalCenterModule} activeTeamId={activeTeamId} members={collaborationMembers} onActiveTeamChange={setActiveTeamId} onModuleChange={setPersonalCenterModule} onOpenChange={changePersonalInfoOpen} onStateChange={setPersonalCenterState} open={personalInfoOpen} state={personalCenterState} />

      <main className="main-content">
        <TaskWorkspace
            currentUserId={currentUserId}
            filters={taskFilters}
            hidden={activeSection !== "home" && activeSection !== "tasks" && activeSection !== "conversation"}
            members={collaborationMembers}
            nodes={workspaceNodes}
            onCreateTask={startNewTaskConversation}
            onFiltersChange={setTaskFilters}
            onManageTags={() => { setActiveSection("settings"); focusPrimaryHeadingAfterNavigation(); }}
            onQueryChange={setTaskQuery}
            onTaskSelect={(task) => openTask(task.id)}
            onShowWorkbench={() => showPrimarySection("home")}
            query={taskQuery}
            selectedTaskId={selectedTaskId}
            showingCreation={activeSection === "conversation"}
            showingWorkbench={activeSection === "home"}
            tagDefinitions={tagDefinitions}
            workbench={<PersonalWorkbench
              currentUserName={currentUserName}
              hidden={activeSection !== "home"}
              model={personalWorkbenchModel}
              onOpenEvidence={openWorkbenchEvidence}
              onOpenTask={(taskId) => { setTaskAttentionTarget(null); openTask(taskId); }}
              onOpenTaskList={showTaskList}
            />}
            creation={creationSessionOpen ? <TaskCreationPage
              onCancel={() => { setCreationSessionOpen(false); showTaskList(); }}
              onDraftStart={() => { creationSessionCompleted.current = false; }}
              active={activeSection === "conversation"}
              currentUserId={currentUserId}
              existingTasks={taskCreationExistingTasks}
              key={conversationRevision}
              members={collaborationMembers}
              onCreateTaskPlan={createTaskPlanFromConversation}
              onCreateSubtask={(parentTaskId, draft) => createTaskPlanFromConversation(draft, parentTaskId)}
              onOpenTask={openTask}
              tags={tagDefinitions}
            /> : null}
        >
          {selectedTaskId && selectedTaskDetail ? (
          <TaskDetail
            key={selectedTaskId}
            aiAdjustmentContext={selectedAiAdjustmentContext}
            effortTasks={selectedEffortTasks}
            recordedActivities={taskActivityStore[selectedTaskId] ?? []}
            onTaskEffortChange={saveTaskEffort}
            childTasks={selectedChildTasks}
            dependencyTasks={selectedDependencyTasks}
            dependencyTaskIds={selectedDependencyTaskIds}
            currentUser={currentUserName}
            initialAttentionTarget={taskAttentionTarget}
            initialProposedOwnerId={selectedLegacyTask?.proposedOwnerId ?? taskOwnerProposals[selectedTaskId] ?? (selectedTreeTask?.kind === "task" ? selectedTreeTask.proposedOwnerId : undefined)}
            members={collaborationMembers}
            onActivityAppend={(activity) => appendActivityForTask(selectedTaskId, activity)}
            onAiAdjustmentApply={applyTaskAiAdjustment}
            onCreateSubtask={createSubtask}
            onDeleteSubtask={requestDeleteSubtask}
            onSubtaskCriteriaSave={saveSubtaskCriteria}
            onTaskCriteriaSave={saveTaskCriteria}
            onInitialAttentionTargetHandled={() => setTaskAttentionTarget(null)}
            onOpenRelatedTask={openTask}
            onOwnerProposalChange={changeOwnerProposal}
            onOwnerChange={changeOwner}
            onParticipantsChange={changeParticipants}
            pathItems={selectedTaskPath}
            onPathSelect={(nodeId) => {
              const node = workspaceNodes.find((item) => item.id === nodeId);
              if (node?.kind === "task") {
                setTaskAttentionTarget(selectedTreeTask?.kind === "task" && selectedTreeTask.parentTaskId === node.id
                  ? { kind: "subtasks", targetId: selectedTreeTask.id } : null);
                openTask(node.id);
              } else {
                showTaskList();
              }
            }}
            task={selectedTaskDetail}
            taskId={selectedTaskId}
            plannedEndOn={selectedTaskPeriodOverride === undefined ? (selectedTreeTask?.kind === "task" ? selectedTreeTask.plannedEndOn : undefined) ?? selectedLegacyTask?.plannedEndOn : selectedTaskPeriodOverride?.end}
            plannedStartOn={selectedTaskPeriodOverride === undefined ? (selectedTreeTask?.kind === "task" ? selectedTreeTask.plannedStartOn : undefined) ?? selectedLegacyTask?.plannedStartOn : selectedTaskPeriodOverride?.start}
            tagDefinitions={tagDefinitions}
            tags={selectedTreeTask?.kind === "task" ? selectedTreeTask.labels ?? [] : []}
            onTaskStatusChange={selectedTreeTask?.kind === "task" ? (status) => {
              changeTaskStatus(selectedTaskId, status);
            } : undefined}
            onTaskAppearanceChange={changeTaskAppearance}
            onTaskGoalChange={changeTaskGoal}
            onTaskTitleChange={changeTaskTitle}
            onTaskPeriodChange={changeTaskPeriod}
            onTagsChange={(labels) => changeTaskTags(selectedTaskId, labels)}
          />
          ) : null}
        </TaskWorkspace>

        {activeSection === "ai" ? (
          <AiConnectionPage />
        ) : activeSection === "settings" ? (
          <TagManagementPage
            tags={tagDefinitions}
            onBack={showTaskList}
            onChange={setTagDefinitions}
            onDeleteTag={(tag) => {
              workspaceNodesRef.current.forEach((node) => {
                if (node.kind === "task" && node.labels?.includes(tag)) changeTaskTags(node.id, node.labels.filter((item) => item !== tag));
              });
              setTaskFilters((current) => ({ ...current, tag: current.tag === tag ? "all" : current.tag, tags: current.tags?.filter((name) => name !== tag) }));
            }}
            onRenameTag={(from, to) => {
              workspaceNodesRef.current.forEach((node) => {
                if (node.kind === "task" && node.labels?.includes(from)) changeTaskTags(node.id, node.labels.map((item) => item === from ? to : item));
              });
              setTaskFilters((current) => ({ ...current, tag: current.tag === from ? to : current.tag, tags: current.tags ? [...new Set(current.tags.map((name) => name === from ? to : name))] : undefined }));
            }}
          />
        ) : null}

      </main>
      <Dialog onOpenChange={(open) => { if (!open) { setSubtaskDeleteTarget(null); setSubtaskDeleteError(""); } }} open={Boolean(subtaskDeleteTarget)}>
        <DialogContent className="sm:max-w-md" finalFocus={() => subtaskDeleteReturnFocus.current?.isConnected ? subtaskDeleteReturnFocus.current : document.getElementById("task-detail-tab-subtasks") ?? false} initialFocus={subtaskDeleteCancel}>
          <DialogTitle>删除子任务？</DialogTitle>
          <DialogDescription>{subtaskDeletion.preview
            ? `「${subtaskDeletion.preview.task.name}」${subtaskDeletion.preview.descendantCount > 0 ? `及其 ${subtaskDeletion.preview.descendantCount} 个下级任务` : ""}将被永久删除，无法撤销。`
            : "当前子任务暂不可删除，请核对提示后重试。"}</DialogDescription>
          {subtaskDeletion.preview && <p>这些任务的本地讨论、文件修改及未保存的文件草稿也会移除。</p>}
          {Boolean(subtaskDeletion.preview?.dependencyTasks.length) && <p>另有 {subtaskDeletion.preview!.dependencyTasks.length} 个任务引用了这些前置任务。删除后将移除对应依赖，其他任务本身保留。</p>}
          {(subtaskDeleteError || subtaskDeletion.error) && <p className="task-file-dialog-error" role="alert">{subtaskDeleteError || subtaskDeletion.error}</p>}
          <DialogFooter>
            <Button onClick={() => { setSubtaskDeleteTarget(null); setSubtaskDeleteError(""); }} ref={subtaskDeleteCancel} type="button" variant="outline">取消</Button>
            <Button disabled={!subtaskDeletion.preview || Boolean(taskStorageRecoveryError)} onClick={confirmDeleteSubtask} type="button" variant="destructive">{subtaskDeletion.preview?.descendantCount ? `删除子任务及 ${subtaskDeletion.preview.descendantCount} 个下级任务` : "删除子任务"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {cliConnectionOpen && (
        <CliConnectionDialog
          onClose={() => setCliConnectionOpen(false)}
          onConnected={() => {
            persistStoredText(localAiStorageKey, "true");
          }}
        />
      )}
      {taskStorageRecoveryError && <Dialog open><DialogContent showCloseButton={false}><DialogTitle>先恢复本地任务记录</DialogTitle><DialogDescription>{taskStorageRecoveryError}</DialogDescription><p>当前未保存的输入已保留。恢复完成前，暂时停止其他编辑。</p><Button onClick={() => { try { recoverTaskAiStorage(localStorage); setTaskStorageRecoveryError(""); } catch (error) { setTaskStorageRecoveryError(error instanceof Error ? error.message : "恢复尚未完成，请检查浏览器存储后重试。"); } }} type="button">重试恢复</Button></DialogContent></Dialog>}
    </div>
    </PersonDirectoryProvider>
  );
}

/** Resolve unfinished task writes before any task state is read or rendered. */
export default function AppWithTaskRecovery() {
  const [recoveryError, setRecoveryError] = useState(() => {
    try { recoverTaskAiStorage(localStorage); return ""; }
    catch (error) { return error instanceof Error ? error.message : "本地任务记录暂时无法读取。"; }
  });
  if (!recoveryError) return <App />;
  return <main className="task-storage-recovery"><h1>本地任务记录需要恢复</h1><p role="alert">{recoveryError}</p><p>尚未加载任务，避免覆盖原记录。检查浏览器存储设置后可重试。</p><Button onClick={() => { try { recoverTaskAiStorage(localStorage); setRecoveryError(""); } catch (error) { setRecoveryError(error instanceof Error ? error.message : "恢复未完成，请重试。"); } }} type="button">重试恢复</Button></main>;
}
