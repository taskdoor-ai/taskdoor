import { effortEstimateSchema, type TaskEffortEstimate } from "../lib/taskEffort";

type BaseNode = {
  id: string;
  kind: "folder" | "task" | "file";
  name: string;
  parentId: string | null;
  updatedAt: string;
};

export type FolderNode = BaseNode & { kind: "folder" };

export type TaskIconTone = "neutral" | "blue" | "cyan" | "green" | "amber" | "red" | "purple" | "pink";
export type TaskIconName = "list-todo" | "clipboard-check" | "target" | "flag" | "briefcase" | "file-check" | "chart" | "sparkles";
type WorkspaceTaskStatus = "待开始" | "进行中" | "待审核" | "已阻塞" | "已完成" | "已取消";

export type TaskNode = BaseNode & {
  kind: "task";
  completionCriteria?: string[];
  executionTips?: string[];
  effortEstimate?: TaskEffortEstimate;
  proposedOwnerId?: string;
  createdFrom?: "task-planner" | "task-editor";
  createdBy?: string;
  createdAt?: string;
  dependsOnTaskIds?: string[];
  ownerId: string;
  participantIds?: string[];
  parentTaskId?: string;
  plannedEndOn?: string;
  plannedStartOn?: string;
  status: WorkspaceTaskStatus;
  goal?: string;
  dueAt?: string;
  iconName?: TaskIconName;
  iconTone?: TaskIconTone;
  labels?: string[];
};

export type FileNode = BaseNode & {
  kind: "file";
  fileType: string;
  size?: string;
};

export type WorkspaceNode = FolderNode | TaskNode | FileNode;

export const workspaceRootId = "workspace-root";
export const creatorCommerceCampaignId = "fragrance-campaign";
export const creatorCommerceMainTaskId = "fragrance-creator-wrapup";

/** 当前产品演示基准：一个活动任务组，以及一个不带父子关系的代表性任务。 */
export const workspaceNodes: WorkspaceNode[] = [
  { id: workspaceRootId, kind: "folder", name: "任务", parentId: null, updatedAt: "刚刚" },
  { id: creatorCommerceCampaignId, kind: "folder", name: "香氛礼盒达人带货", parentId: workspaceRootId, updatedAt: "今天" },
  {
    id: creatorCommerceMainTaskId,
    kind: "task",
    name: "香氛礼盒达人带货收尾",
    parentId: creatorCommerceCampaignId,
    ownerId: "周岚",
    participantIds: ["陈默", "林洁", "高远", "梁川", "许宁", "韩序", "苏禾"],
    status: "进行中",
    dueAt: "9 月 12 日",
    goal: "统筹香氛礼盒达人带货项目收尾，确认各责任环节完成并对最终结果负责。",
    iconName: "target",
    iconTone: "purple",
    labels: ["高优先级"],
    updatedAt: "今天",
  },
  {
    id: "fragrance-creator-business",
    kind: "task",
    name: "确认第二批达人名单与合作档期",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "陈默",
    status: "已完成",
    dueAt: "8 月 29 日",
    goal: "完成第二批达人筛选、建联、佣金谈判与合作档期确认。",
    iconName: "briefcase",
    iconTone: "blue",
    labels: ["达人商务", "高优先级"],
    updatedAt: "20 分钟前",
  },
  {
    id: "fragrance-content",
    kind: "task",
    name: "终审短视频脚本与直播卖点",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "林洁",
    status: "进行中",
    dueAt: "8 月 30 日",
    goal: "完成核心卖点、短视频脚本、直播话术与素材终审。",
    iconName: "sparkles",
    iconTone: "purple",
    labels: ["内容制作"],
    updatedAt: "45 分钟前",
  },
  {
    id: "fragrance-live",
    kind: "task",
    name: "完成直播间彩排与场控清单",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "高远",
    dependsOnTaskIds: ["fragrance-content"],
    status: "已阻塞",
    dueAt: "9 月 3 日",
    goal: "锁定直播排期，完成彩排、场控清单和异常预案。",
    iconName: "clipboard-check",
    iconTone: "amber",
    labels: ["直播执行"],
    updatedAt: "今天",
  },
  {
    id: "fragrance-product",
    kind: "task",
    name: "锁定礼盒价格、赠品与库存",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "梁川",
    status: "已完成",
    dueAt: "9 月 1 日",
    goal: "确认礼盒价格机制、赠品方案、库存水位与履约保障。",
    iconName: "list-todo",
    iconTone: "cyan",
    labels: ["商品运营"],
    updatedAt: "1 小时前",
  },
  {
    id: "fragrance-growth",
    kind: "task",
    name: "调整第二轮投流预算与人群包",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "许宁",
    dependsOnTaskIds: ["fragrance-creator-business"],
    status: "进行中",
    dueAt: "9 月 4 日",
    goal: "根据首轮表现调整投放预算、定向与人群包，控制 ROI。",
    iconName: "chart",
    iconTone: "amber",
    labels: ["投流增长", "高优先级"],
    updatedAt: "35 分钟前",
  },
  {
    id: "fragrance-data",
    kind: "task",
    name: "更新 GMV 看板与渠道归因",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "韩序",
    dependsOnTaskIds: ["fragrance-growth"],
    status: "已完成",
    dueAt: "9 月 8 日",
    goal: "更新 GMV 指标看板、统一渠道归因口径并准备项目复盘。",
    iconName: "chart",
    iconTone: "blue",
    labels: ["数据复盘"],
    updatedAt: "15 分钟前",
  },
  {
    id: "fragrance-compliance",
    kind: "task",
    name: "审核素材宣称与达人合同",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "苏禾",
    dependsOnTaskIds: ["fragrance-content", "fragrance-creator-business"],
    status: "待开始",
    dueAt: "8 月 31 日",
    goal: "完成素材宣称、广告法、达人合同与平台规则审核。",
    iconName: "file-check",
    iconTone: "green",
    labels: ["合规审核"],
    updatedAt: "2 小时前",
  },
  {
    id: "fragrance-final-decision",
    kind: "task",
    name: "确认追加投放目标与最终决策",
    parentId: creatorCommerceCampaignId,
    parentTaskId: creatorCommerceMainTaskId,
    ownerId: "周岚",
    dependsOnTaskIds: ["fragrance-data", "fragrance-compliance"],
    participantIds: ["许宁", "韩序"],
    status: "待审核",
    dueAt: "今天 16:00",
    goal: "确认追加投放的 GMV 目标、预算边界与资源优先级，并完成项目最终决策。",
    iconName: "target",
    iconTone: "red",
    labels: ["高优先级"],
    updatedAt: "10 分钟前",
  },
  {
    id: "product-launch-planning",
    kind: "task",
    name: "新品发布会筹备",
    parentId: workspaceRootId,
    ownerId: "周岚",
    participantIds: ["陈默", "林洁"],
    status: "进行中",
    dueAt: "9 月 20 日",
    plannedStartOn: "2026-08-30",
    plannedEndOn: "2026-09-20",
    goal: "统筹新品发布会场地、流程与宣传物料，确保发布会按期落地。",
    iconName: "flag",
    iconTone: "red",
    labels: ["高优先级", "内容制作"],
    updatedAt: "今天",
  },
  {
    id: "product-launch-venue",
    kind: "task",
    name: "场地确认",
    parentId: workspaceRootId,
    parentTaskId: "product-launch-planning",
    ownerId: "陈默",
    status: "进行中",
    dueAt: "9 月 5 日",
    goal: "确认发布会场地、档期、容量与现场配套条件。",
    iconName: "briefcase",
    iconTone: "blue",
    labels: ["高优先级"],
    updatedAt: "1 小时前",
  },
  {
    id: "product-launch-run-of-show",
    kind: "task",
    name: "发布会流程设计",
    parentId: workspaceRootId,
    parentTaskId: "product-launch-planning",
    ownerId: "林洁",
    status: "待开始",
    dueAt: "9 月 10 日",
    goal: "完成发布会完整流程、嘉宾衔接与现场应急预案。",
    iconName: "clipboard-check",
    iconTone: "purple",
    labels: ["内容制作"],
    updatedAt: "今天",
  },
  {
    id: "product-launch-promo-assets",
    kind: "task",
    name: "宣传物料制作",
    parentId: workspaceRootId,
    parentTaskId: "product-launch-planning",
    ownerId: "林洁",
    status: "待开始",
    dueAt: "9 月 15 日",
    goal: "完成发布会主视觉、邀请函与渠道宣传物料制作。",
    iconName: "sparkles",
    iconTone: "pink",
    labels: ["内容制作"],
    updatedAt: "今天",
  },
  {
    id: "weekly-retro-notes",
    kind: "task",
    name: "整理本周团队复盘纪要",
    parentId: workspaceRootId,
    ownerId: "周岚",
    participantIds: ["陈默", "林洁"],
    status: "进行中",
    dueAt: "9 月 1 日",
    goal: "汇总本周关键决定、未解决问题与下周行动项，形成可直接共享的团队复盘纪要。",
    iconName: "clipboard-check",
    iconTone: "blue",
    labels: ["内容制作"],
    updatedAt: "12 分钟前",
  },
];

const taskStatuses = new Set<WorkspaceTaskStatus>(["待开始", "进行中", "待审核", "已阻塞", "已完成", "已取消"]);
const taskIconNames = new Set<TaskIconName>(["list-todo", "clipboard-check", "target", "flag", "briefcase", "file-check", "chart", "sparkles"]);
const taskIconTones = new Set<TaskIconTone>(["neutral", "blue", "cyan", "green", "amber", "red", "purple", "pink"]);
const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null;
const asOptionalString = (value: unknown) => typeof value === "string" && value.trim() ? value : undefined;
const asStringList = (value: unknown) => Array.isArray(value)
  ? value.filter((item): item is string => typeof item === "string" && Boolean(item.trim()))
  : undefined;

const normalizeFolderNode = (value: unknown): FolderNode | null => {
  if (!isRecord(value) || value.kind !== "folder") return null;
  if (typeof value.id !== "string" || !value.id.trim() || value.id === workspaceRootId) return null;
  if (typeof value.name !== "string" || !value.name.trim()) return null;
  if (typeof value.updatedAt !== "string" || !value.updatedAt.trim()) return null;
  return {
    id: value.id,
    kind: "folder",
    name: value.name,
    parentId: typeof value.parentId === "string" && value.parentId.trim() ? value.parentId : workspaceRootId,
    updatedAt: value.updatedAt,
  };
};

const normalizeFileNode = (value: unknown): FileNode | null => {
  if (!isRecord(value) || value.kind !== "file") return null;
  if (typeof value.id !== "string" || !value.id.trim() || value.id === workspaceRootId) return null;
  if (typeof value.name !== "string" || !value.name.trim()) return null;
  if (typeof value.updatedAt !== "string" || !value.updatedAt.trim()) return null;
  if (typeof value.fileType !== "string" || !value.fileType.trim()) return null;
  if (value.size !== undefined && (typeof value.size !== "string" || !value.size.trim())) return null;
  return {
    id: value.id,
    kind: "file",
    name: value.name,
    parentId: typeof value.parentId === "string" && value.parentId.trim() ? value.parentId : workspaceRootId,
    updatedAt: value.updatedAt,
    fileType: value.fileType,
    ...(typeof value.size === "string" ? { size: value.size } : {}),
  };
};

const normalizeTaskNode = (value: unknown): TaskNode | null => {
  if (!isRecord(value) || value.kind !== "task") return null;
  if (typeof value.id !== "string" || !value.id.trim() || value.id === workspaceRootId) return null;
  if (typeof value.name !== "string" || !value.name.trim()) return null;
  if (typeof value.ownerId !== "string" || (!value.ownerId.trim() && value.createdFrom !== "task-planner" && value.createdFrom !== "task-editor")) return null;
  if (typeof value.updatedAt !== "string" || !value.updatedAt.trim()) return null;
  if (typeof value.status !== "string" || !taskStatuses.has(value.status as WorkspaceTaskStatus)) return null;

  const labels = asStringList(value.labels);
  const participantIds = asStringList(value.participantIds);
  const dependsOnTaskIds = asStringList(value.dependsOnTaskIds);
  const effortEstimate = effortEstimateSchema.safeParse(value.effortEstimate);
  const iconName = typeof value.iconName === "string" && taskIconNames.has(value.iconName as TaskIconName)
    ? value.iconName as TaskIconName
    : undefined;
  const iconTone = typeof value.iconTone === "string" && taskIconTones.has(value.iconTone as TaskIconTone)
    ? value.iconTone as TaskIconTone
    : undefined;
  return {
    id: value.id,
    kind: "task",
    name: value.name,
    ownerId: value.ownerId,
    parentId: typeof value.parentId === "string" && value.parentId.trim() ? value.parentId : workspaceRootId,
    status: value.status as WorkspaceTaskStatus,
    updatedAt: value.updatedAt,
    ...(dependsOnTaskIds ? { dependsOnTaskIds } : {}),
    ...(asStringList(value.completionCriteria) ? { completionCriteria: asStringList(value.completionCriteria) } : {}),
    ...(asStringList(value.executionTips) ? { executionTips: asStringList(value.executionTips) } : {}),
    ...(effortEstimate.success ? { effortEstimate: effortEstimate.data } : {}),
    ...(value.createdFrom === "task-planner" || value.createdFrom === "task-editor" ? { createdFrom: value.createdFrom } : {}),
    ...(asOptionalString(value.createdBy) ? { createdBy: value.createdBy as string } : {}),
    ...(asOptionalString(value.createdAt) ? { createdAt: value.createdAt as string } : {}),
    ...(asOptionalString(value.proposedOwnerId) ? { proposedOwnerId: value.proposedOwnerId as string } : {}),
    ...(labels ? { labels } : {}),
    ...(participantIds ? { participantIds } : {}),
    ...(asOptionalString(value.parentTaskId) ? { parentTaskId: value.parentTaskId as string } : {}),
    ...(asOptionalString(value.plannedEndOn) ? { plannedEndOn: value.plannedEndOn as string } : {}),
    ...(asOptionalString(value.plannedStartOn) ? { plannedStartOn: value.plannedStartOn as string } : {}),
    // An explicit empty goal is a saved clear; only an absent field may fall back to a seed.
    ...(typeof value.goal === "string" ? { goal: value.goal } : {}),
    ...(asOptionalString(value.dueAt) ? { dueAt: value.dueAt as string } : {}),
    ...(iconName ? { iconName } : {}),
    ...(iconTone ? { iconTone } : {}),
  };
};

const cloneWorkspaceFixture = (): WorkspaceNode[] => workspaceNodes.map((node) => node.kind === "task"
  ? {
      ...node,
      ...(node.labels ? { labels: [...node.labels] } : {}),
      ...(node.dependsOnTaskIds ? { dependsOnTaskIds: [...node.dependsOnTaskIds] } : {}),
      ...(node.participantIds ? { participantIds: [...node.participantIds] } : {}),
    }
  : { ...node });

/** 当前版本只做结构归一，不覆盖用户已创建、修改或删除的任务。 */
export function normalizeWorkspaceNodes(value: unknown): WorkspaceNode[] {
  if (!Array.isArray(value)) return cloneWorkspaceFixture();
  const storedRoot = value.find((node) => isRecord(node)
    && node.id === workspaceRootId
    && node.kind === "folder"
    && typeof node.name === "string"
    && Boolean(node.name.trim())
    && node.parentId === null
    && typeof node.updatedAt === "string"
    && Boolean(node.updatedAt.trim()));
  const root: FolderNode = storedRoot && isRecord(storedRoot)
    ? { id: workspaceRootId, kind: "folder", name: storedRoot.name as string, parentId: null, updatedAt: storedRoot.updatedAt as string }
    : { ...workspaceNodes[0] as FolderNode };
  const seenIds = new Set([workspaceRootId]);
  const nodes = value.flatMap((node) => {
    const normalized = normalizeFolderNode(node) ?? normalizeTaskNode(node) ?? normalizeFileNode(node);
    if (!normalized || seenIds.has(normalized.id)) return [];
    seenIds.add(normalized.id);
    return [normalized];
  });
  const folders = nodes.filter((node): node is FolderNode => node.kind === "folder");
  const folderById = new Map(folders.map((folder) => [folder.id, folder]));
  const directFolderParents = new Map(folders.flatMap((folder) => folder.parentId
    && folder.parentId !== folder.id
    && folderById.has(folder.parentId)
    ? [[folder.id, folder.parentId] as const]
    : []));
  const cyclicFolderIds = new Set<string>();
  const resolvedFolderIds = new Set<string>();
  for (const folder of folders) {
    if (resolvedFolderIds.has(folder.id)) continue;
    const path: string[] = [];
    const positionById = new Map<string, number>();
    let currentId: string | undefined = folder.id;
    while (currentId && !resolvedFolderIds.has(currentId)) {
      const cycleStart = positionById.get(currentId);
      if (cycleStart !== undefined) {
        path.slice(cycleStart).forEach((id) => cyclicFolderIds.add(id));
        break;
      }
      positionById.set(currentId, path.length);
      path.push(currentId);
      currentId = directFolderParents.get(currentId);
    }
    path.forEach((id) => resolvedFolderIds.add(id));
  }
  const tasks = nodes.filter((node): node is TaskNode => node.kind === "task");
  const taskById = new Map(tasks.map((task) => [task.id, task]));
  const directTaskParents = new Map(tasks.flatMap((task) => task.parentTaskId
    && task.parentTaskId !== task.id
    && taskById.has(task.parentTaskId)
    ? [[task.id, task.parentTaskId] as const]
    : []));
  const cyclicTaskIds = new Set<string>();
  const resolvedTaskIds = new Set<string>();
  for (const task of tasks) {
    if (resolvedTaskIds.has(task.id)) continue;
    const path: string[] = [];
    const positionById = new Map<string, number>();
    let currentId: string | undefined = task.id;
    while (currentId && !resolvedTaskIds.has(currentId)) {
      const cycleStart = positionById.get(currentId);
      if (cycleStart !== undefined) {
        path.slice(cycleStart).forEach((id) => cyclicTaskIds.add(id));
        break;
      }
      positionById.set(currentId, path.length);
      path.push(currentId);
      currentId = directTaskParents.get(currentId);
    }
    path.forEach((id) => resolvedTaskIds.add(id));
  }
  const safeFolderParent = (folder: FolderNode) => {
    if (cyclicFolderIds.has(folder.id)) return workspaceRootId;
    return directFolderParents.get(folder.id) ?? workspaceRootId;
  };

  return [root, ...nodes.map((node) => {
    if (node.kind === "folder") return { ...node, parentId: safeFolderParent(node) };
    if (node.kind === "file") {
      return { ...node, parentId: folderById.has(node.parentId ?? "") ? node.parentId : workspaceRootId };
    }
    const { parentTaskId: _parentTaskId, ...task } = node;
    const parentTaskId = directTaskParents.get(node.id);
    return {
      ...task,
      parentId: folderById.has(node.parentId ?? "") ? node.parentId : workspaceRootId,
      ...(parentTaskId && !cyclicTaskIds.has(node.id) ? { parentTaskId } : {}),
    };
  })];
}
