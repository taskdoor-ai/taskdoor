import { ArrowRight, Check, CheckCheck, ChevronRight, GitBranch, Layers3, Lightbulb, Plus, RotateCcw, Sparkles } from "lucide-react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { taskCreationScenarios, type TaskCreationScenarioId } from "../data/taskCreationScenarios";
import type { TagDefinition } from "../data/tagGroups";
import type { ExistingTaskCandidate } from "../lib/taskCreationScenario";
import type { TaskPlanDraft } from "../lib/taskAssistantProtocol";
import { toTaskPlanDraft, validateCreationForm, type CreationForm } from "../lib/taskCreationForm";
import { reconcileCreationEffort } from "../lib/taskCreationEffort";
import { planTaskCreation, resolveCreationRelationship, type CreationPlanningQuestion, type CreationPlanningResult } from "../lib/taskCreationPlanning";
import { CREATION_MOCK_STEP_MS, getCreationDisplayStage, getCreationFeedback, recordCreationAdjustmentProgress, type CreationProcess } from "../lib/taskCreationProgress";
import { playMockAiSteps } from "../lib/taskAiFeedback";
import { applyDraftTaskAiAdjustment, createDraftTaskAiContext } from "../lib/taskAiAdjustmentAdapters";
import type { TaskAiAdjustmentProgress, TaskAiAdjustmentProposal, TaskAiAdjustmentScope } from "../lib/taskAiAdjustmentTypes";
import type { Member } from "./MemberSelector";
import { AnimatedAgentChatInput } from "./AnimatedAgentChatInput";
import { TaskCreationExistingTaskCard } from "./TaskCreationExistingTaskCard";
import { TaskCreationPlanEditor } from "./TaskCreationPlanEditor";
import { TaskCreationProcess } from "./TaskCreationProcess";
import { TaskAiAdjustButton, TaskAiAdjustmentPopover, useTaskAiAdjustmentDrafts } from "./TaskAiAdjustmentPopover";
import { Button } from "./ui/button";
import { Textarea } from "./ui/input";
import "../styles/task-heading.css";
import "../styles/task-creation-page.css";
import "../styles/task-ai-adjustment.css";
import "../styles/task-criteria-editor.css";
import "../styles/task-creation-subtask.css";

type CreationResult = { createdCount: number; mainTaskId: string; taskTitles: string[] };
type Props = {
  active?: boolean;
  currentUserId: string;
  existingTasks: ExistingTaskCandidate[];
  members: Member[];
  tags: TagDefinition[];
  onCreateTaskPlan: (draft: TaskPlanDraft) => CreationResult;
  onCreateSubtask: (parentTaskId: string, draft: TaskPlanDraft) => CreationResult;
  onOpenTask: (taskId: string) => void;
  onCancel: () => void;
  onDraftStart?: () => void;
};
type CreationWorkspaceDraft = {
  request: string;
  scenarioId?: TaskCreationScenarioId;
  planning: CreationPlanningResult | null;
  answers: { goal?: string; deliverable?: string };
  processes: CreationProcess[];
  editingBrief: boolean;
};
const emptyWorkspaceDraft = (): CreationWorkspaceDraft => ({ request: "", planning: null, answers: {}, processes: [], editingBrief: false });

function ClarificationFields({ questions, answers, onAnswer, disabled }: {
  questions: CreationPlanningQuestion[];
  answers: CreationWorkspaceDraft["answers"];
  onAnswer: (field: "goal" | "deliverable", value: string) => void;
  disabled: boolean;
}) {
  return <div className="creation-questions">{questions.map((question, index) => <section className="creation-question" key={question.field}>
    <label htmlFor={"creation-answer-" + question.field}>{question.title}</label>
    <div aria-label={question.title + "的建议选项"} className="creation-answer-options">
      {question.choices.map(choice => <button aria-pressed={answers[question.field] === choice} disabled={disabled} key={choice} onClick={() => onAnswer(question.field, choice)} type="button">{answers[question.field] === choice && <Check size={13} />}{choice}</button>)}
    </div>
    <Textarea autoFocus={index === 0} disabled={disabled} id={"creation-answer-" + question.field} onChange={event => onAnswer(question.field, event.target.value)} placeholder={question.placeholder} required rows={2} value={answers[question.field] ?? ""} />
  </section>)}</div>;
}

export function TaskCreationPage({ active = true, currentUserId, existingTasks, members, tags, onCreateTaskPlan, onCreateSubtask, onOpenTask, onCancel, onDraftStart }: Props) {
  const context = { currentUserId, existingTasks, members, tags: tags.map(t => t.name), currentDate: new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai" }).format(new Date()) };
  const [workspace, setWorkspace] = useState<CreationWorkspaceDraft>(emptyWorkspaceDraft);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [planningNotice, setPlanningNotice] = useState("");
  const [result, setResult] = useState<CreationResult | null>(null);
  const [aiScope, setAiScope] = useState<TaskAiAdjustmentScope | null>(null);
  const [aiOpen, setAiOpen] = useState(false);
  const aiDraftSession = useTaskAiAdjustmentDrafts();
  const [adjustmentNotice, setAdjustmentNotice] = useState("");
  const [dirtySubtasks, setDirtySubtasks] = useState<Record<string, boolean>>({});
  const hasUnsavedSubtasks = Object.values(dirtySubtasks).some(Boolean);
  const unsavedMessage = "子任务有未能同步的修改，请展开核对。";
  const onSubtaskDirtyChange = (taskId: string, dirty: boolean) => setDirtySubtasks(current => {
    if (Boolean(current[taskId]) === dirty) return current;
    const next = { ...current };
    if (dirty) next[taskId] = true; else delete next[taskId];
    return next;
  });
  const aiReturnFocus = useRef<HTMLElement | null>(null);
  const adjustmentStop = useRef<{ id: string; stop: () => void } | null>(null);
  const latestAiTaskId = useRef<string | null>(null);
  const drafts = useRef(new Map<string, CreationWorkspaceDraft>());
  const creating = useRef(false);
  const planningRun = useRef(0);
  const planningAbort = useRef<AbortController | null>(null);
  const restorePlanningFocus = useRef(false);
  const requestRef = useRef<HTMLTextAreaElement>(null);
  const pageRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const focusedStage = useRef("");
  const reducedMotion = useReducedMotion();
  const planning = workspace.planning;
  const form = planning && (planning.stage === "review" || planning.stage === "decision") ? planning.form : null;
  const aiContext = form ? createDraftTaskAiContext(form, members, currentUserId) : null;
  latestAiTaskId.current = aiContext?.task.id ?? null;
  const latestProcess = workspace.processes.at(-1);
  const adjustmentRunning = latestProcess?.kind === "adjustment" && latestProcess.status === "running";
  const displayStage = getCreationDisplayStage(planning, { busy, editingBrief: workspace.editingBrief });
  const showDescribe = displayStage === "describe";
  const validation = form ? validateCreationForm(form, members) : null;
  const stageKey = displayStage === "review" ? form?.mainTask.clientId ?? "review" : displayStage;
  const stageLabel = showDescribe ? "描述任务需求" : displayStage === "planning" ? "正在整理需求" : displayStage === "clarify" ? "补充关键信息" : displayStage === "decision" ? "确认任务关系" : "任务方案详情";
  const updateProcess = (id: CreationProcess["id"], patch: Partial<CreationProcess>) => setWorkspace(current => ({
    ...current, processes: current.processes.map(process => process.id === id ? { ...process, ...patch } : process),
  }));
  const updateAdjustmentProgress = (progress: TaskAiAdjustmentProgress, stop?: () => void) => {
    if (progress.taskId !== latestAiTaskId.current) return;
    if (progress.status === "running" && stop) adjustmentStop.current = { id: progress.id, stop };
    else if (adjustmentStop.current?.id === progress.id) adjustmentStop.current = null;
    setWorkspace(current => {
      const draft = current.planning;
      if (!draft || draft.stage !== "review" || draft.form.mainTask.clientId !== progress.taskId) return current;
      const processes = recordCreationAdjustmentProgress(current.processes, progress);
      return processes === current.processes ? current : { ...current, processes };
    });
  };
  const stopAdjustment = () => adjustmentStop.current?.stop();

  const focusStage = () => {
    if (!active || !pageRef.current?.getClientRects().length) return;
    if (focusedStage.current === stageKey) return;
    focusedStage.current = stageKey;
    pageRef.current?.scrollIntoView({ block: "start", behavior: "auto" });
    if (showDescribe) requestRef.current?.focus({ preventScroll: true });
    else if (displayStage === "planning") stageRef.current?.querySelector<HTMLButtonElement>('button[aria-label="停止生成方案"]')?.focus({ preventScroll: true });
    else if (displayStage === "clarify") stageRef.current?.querySelector("textarea")?.focus({ preventScroll: true });
    else stageRef.current?.focus({ preventScroll: true });
  };

  useEffect(() => () => { planningRun.current += 1; planningAbort.current?.abort(); }, []);

  useEffect(() => {
    if (!active) { setAiOpen(false); return; }
    focusedStage.current = "";
    const frame = requestAnimationFrame(focusStage);
    return () => cancelAnimationFrame(frame);
  }, [active]);

  useEffect(() => {
    if (!active) return;
    if (busy || !restorePlanningFocus.current) return;
    restorePlanningFocus.current = false;
    const frame = requestAnimationFrame(() => {
      stageRef.current?.querySelector<HTMLTextAreaElement>("textarea:not(:disabled)")?.focus({ preventScroll: true });
    });
    return () => cancelAnimationFrame(frame);
  }, [busy, active]);

  const stopPlanning = () => {
    const run = planningRun.current;
    planningRun.current += 1;
    planningAbort.current?.abort(); planningAbort.current = null;
    restorePlanningFocus.current = true;
    updateProcess(run, { status: "stopped", outcome: "生成已停止，需求和原有方案已保留" });
    setBusy(false);
    setPlanningNotice("已停止整理，需求和原有方案均已保留。");
  };

  const clearTransientState = () => {
    planningRun.current += 1;
    planningAbort.current?.abort(); planningAbort.current = null;
    restorePlanningFocus.current = false;
    adjustmentStop.current?.stop(); adjustmentStop.current = null;
    creating.current = false;
    setPlanningNotice("");
    setBusy(false); setError(""); setAdjustmentNotice("");
    setAiOpen(false); setAiScope(null); setResult(null);
    onDraftStart?.();
  };
  const openScenario = (id: TaskCreationScenarioId | "custom") => {
    if (busy || adjustmentRunning) return;
    if (hasUnsavedSubtasks) { setError(unsavedMessage); return; }
    if (!result && workspace.request.trim()) drafts.current.set(workspace.scenarioId ?? "custom", workspace);
    const scenario = taskCreationScenarios.find(item => item.id === id);
    setWorkspace(drafts.current.get(id) ?? { ...emptyWorkspaceDraft(), request: scenario?.prompt ?? "", scenarioId: scenario?.id });
    clearTransientState();
    requestRef.current?.focus();
  };
  const startAnother = () => { setWorkspace(emptyWorkspaceDraft()); clearTransientState(); };
  const updateForm = (next: CreationForm) => {
    if (result || busy || adjustmentRunning || planning?.stage !== "review") return;
    setWorkspace(current => ({ ...current, planning: { stage: "review", form: reconcileCreationEffort(planning.form, next), summary: planning.summary } }));
    setAdjustmentNotice(""); setError("");
  };
  const generatePlan = async (answers?: CreationWorkspaceDraft["answers"]) => {
    if (planningAbort.current || busy || result || !workspace.request.trim()) return;
    const run = ++planningRun.current;
    const controller = new AbortController();
    planningAbort.current = controller;
    restorePlanningFocus.current = false;
    const planningRequest = form?.request.trim() ?? (planning?.stage === "clarify" || planning?.stage === "unavailable" ? planning.request.trim() : undefined);
    const effectiveAnswers = answers ?? (planningRequest === workspace.request.trim() ? workspace.answers : {});
    setBusy(true); setError(""); setPlanningNotice("");
    try {
      const next = planTaskCreation(workspace.request, context, { scenarioId: workspace.scenarioId, answers: effectiveAnswers });
      const feedback = getCreationFeedback(next);
      const title = answers ? "补充信息后规划" : workspace.processes.length ? "重新生成" : "初次生成";
      setWorkspace(current => ({ ...current, processes: [...current.processes, {
        id: run, title, request: workspace.request.trim(), answers: { ...effectiveAnswers }, steps: feedback,
        activeStep: 0, status: "running",
      }] }));
      // Readable Mock playback at page level; not a model/tool trace or saved report.
      const completed = await playMockAiSteps(feedback.length, {
        signal: controller.signal,
        stepMs: CREATION_MOCK_STEP_MS,
        onStep: index => { if (run === planningRun.current) updateProcess(run, { activeStep: index }); },
      });
      if (!completed || run !== planningRun.current) return;
      const outcome = next.stage === "review" ? "候选方案已生成" : next.stage === "clarify" ? "需要补充关键信息" : next.stage === "decision" ? "任务关系待确认" : "当前输入需要调整";
      updateProcess(run, { activeStep: Math.max(0, feedback.length - 1), status: "completed", outcome });
      if (next.stage === "unavailable") {
        restorePlanningFocus.current = true;
        setError(next.message);
        if (!planning) setWorkspace(current => ({ ...current, planning: next }));
        return;
      }
      setWorkspace(current => ({
        ...current, planning: next, answers: effectiveAnswers, editingBrief: false,
        scenarioId: next.stage === "clarify" ? next.scenarioId : next.form.scenarioId,
      }));
      setAiOpen(false); setAiScope(null); setAdjustmentNotice("");
      if (next.stage === "clarify" && answers) {
        restorePlanningFocus.current = true;
        setError("还需要明确以下信息：" + next.questions.map(question => question.title).join(" "));
      }
    } catch (caught) {
      if (run === planningRun.current) {
        restorePlanningFocus.current = true;
        updateProcess(run, { status: "failed", outcome: "生成未完成，需求和原有方案已保留" });
        setError(caught instanceof Error ? caught.message : "暂时无法生成方案，需求和已有方案已保留，请重试。");
      }
    } finally {
      if (run === planningRun.current) {
        planningAbort.current = null;
        setBusy(false);
      }
    }
  };
  const resolveRelationship = (decision: "attach" | "independent") => {
    if (!form || result || busy) return;
    const next = resolveCreationRelationship(form, decision, context);
    if ("error" in next) { setError(next.error); return; }
    setWorkspace(current => ({ ...current, planning: { stage: "review", ...next, form: reconcileCreationEffort(form, next.form) } }));
    setError(""); setAiOpen(false); setAiScope(null); setAdjustmentNotice("");
  };
  const openAiAdjustment = (scope: TaskAiAdjustmentScope, returnFocus?: HTMLElement | null) => {
    if (!form || result || busy || planning?.stage !== "review") return;
    if (hasUnsavedSubtasks) { setError(unsavedMessage); return; }
    aiReturnFocus.current = returnFocus ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null);
    setAiScope(scope); setAiOpen(true); setAdjustmentNotice("");
  };
  const applyAiAdjustment = (proposal: TaskAiAdjustmentProposal) => {
    if (!aiContext || result || busy || planning?.stage !== "review") throw new Error("当前方案不可修改，请返回方案后重试。");
    if (planning.form.decision === "attach" && existingTasks.find(task => task.id === planning.form.candidate?.id)?.goal !== planning.form.candidate?.goal) {
      throw new Error("主任务目标已变化，请重新确认关联后再调整。");
    }
    const next = applyDraftTaskAiAdjustment(planning.form, aiContext, proposal);
    setWorkspace(current => ({ ...current, planning: { stage: "review", form: reconcileCreationEffort(planning.form, next), summary: planning.summary } }));
    setAdjustmentNotice("调整已应用到草稿，确认创建后才会加入任务列表。"); setError("");
  };
  const submit = () => {
    if (creating.current) return;
    if (hasUnsavedSubtasks) { setError(unsavedMessage); return; }
    if (!planning || planning.stage !== "review" || aiOpen || busy || adjustmentRunning) return;
    const form = planning.form;
    const invalid = validateCreationForm(form, members);
    if (invalid) { setError(invalid); return; }
    if (form.decision === "attach") {
      const parent = existingTasks.find(task => task.id === form.candidate?.id);
      if (!parent) { setError("主任务已不存在。方案已保留，请返回需求重新规划。"); return; }
      if (parent.goal !== form.candidate?.goal) {
        setWorkspace(current => ({ ...current, planning: { stage: "decision", form: { ...form, candidate: parent, decision: "pending" }, summary: "主任务目标已变化，请重新确认关联。" } }));
        setError("主任务目标已更新，请重新确认后创建。"); return;
      }
    }
    creating.current = true;
    try {
      const plan = toTaskPlanDraft(form);
      const created = form.decision === "attach" && form.candidate ? onCreateSubtask(form.candidate.id, plan) : onCreateTaskPlan(plan);
      setResult(created); drafts.current.delete(workspace.scenarioId ?? "custom"); setError("");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "创建未完成，方案已保留，请重试。"); creating.current = false; }
  };

  const scenarioPicker = <div aria-label="快速开始" className="animated-agent-suggestions">
    {taskCreationScenarios.map(scenario => {
      const selected = workspace.scenarioId === scenario.id && workspace.request.trim() === scenario.prompt;
      return <button aria-pressed={selected} disabled={busy || adjustmentRunning} key={scenario.id} onClick={() => openScenario(scenario.id)} type="button">
        <Sparkles aria-hidden="true" />{scenario.label}
      </button>;
    })}
  </div>;
  const processActions = form && planning?.stage === "review" && !result
    ? <TaskAiAdjustButton disabled={busy || hasUnsavedSubtasks} label="AI 帮你改任务方案" onClick={anchor => openAiAdjustment(aiScope ?? { kind: "task" }, anchor)} />
    : undefined;
  const cancelProcess = busy ? stopPlanning : adjustmentRunning ? stopAdjustment : undefined;

  return <section className={`task-detail-view task-creation-page${showDescribe ? " creation-start-page" : ""}`} ref={pageRef}>
    <div className="creation-page-top">
      <nav aria-label="任务路径" className="task-detail-path"><span><button onClick={onCancel} type="button">任务</button></span><span><ChevronRight aria-hidden="true" size={12} /><em aria-current="page">新建任务</em></span></nav>
      <div className="creation-page-actions">
        {workspace.scenarioId && drafts.current.has("custom") && !result && <button className="creation-example-trigger" disabled={busy || adjustmentRunning} onClick={() => openScenario("custom")} type="button"><RotateCcw size={13} />返回我的需求</button>}
      </div>
    </div>
    {!showDescribe && <div className="creation-workflow-bar">
      <span className="creation-ai-label"><Sparkles size={14} />AI 辅助创建</span>
    </div>}
    <AnimatePresence mode="wait"><motion.div animate={{ opacity: 1, y: 0 }} aria-label={stageLabel} className={`creation-sheet${showDescribe ? " task-conversation-page is-starting" : ""}`} initial={reducedMotion ? false : { opacity: 0, y: 8 }} key={stageKey} onAnimationComplete={focusStage} ref={stageRef} role="region" tabIndex={-1} transition={{ duration: reducedMotion ? 0 : .18 }}>
      {!showDescribe && planningNotice && <p className="creation-planning-notice" role="status">{planningNotice}</p>}
      {showDescribe ? <div className="task-conversation-workspace"><div className="task-conversation-column">
        <section className="task-conversation-start"><header><h1>今天想推进什么？</h1><p>输入一个任务，或告诉 AgentDoor 你的目标</p></header></section>
        <div className="task-conversation-composer creation-request-panel">
          <AnimatedAgentChatInput
            allowAttachments={false}
            ariaLabel="需求描述"
            autoFocus={active}
            clearOnSend={false}
            disabled={busy}
            hint="Enter 发起 · Shift + Enter 换行"
            inputRef={requestRef}
            onChange={request => { setWorkspace(current => ({ ...current, request })); setError(""); }}
            onSend={() => { void generatePlan(); }}
            placeholder="告诉 AgentDoor 你想推进什么…"
            sendLabel={form ? "重新发起" : "发起"}
            value={workspace.request}
          />
          <div className="creation-request-actions"><span>先生成方案，确认后才创建</span>{form && <Button disabled={busy} onClick={() => { setWorkspace(current => ({ ...current, editingBrief: false })); setError(""); }} type="button" variant="ghost">返回现有方案</Button>}</div>
          {planningNotice && <p className="creation-planning-notice" role="status">{planningNotice}</p>}
          {form && <p className="creation-request-caution">重新生成会替换当前方案；生成失败时保留原方案。也可以通过“AI 帮你改”继续补充需求。</p>}
          {error && <p className="creation-stage-error" role="alert">{error}</p>}
          {workspace.processes.length > 0 && <TaskCreationProcess actions={processActions} onCancel={cancelProcess} processes={workspace.processes} />}
        </div>
        {scenarioPicker}
      </div></div> : <>
        {workspace.processes.length > 0 && <TaskCreationProcess actions={processActions} onCancel={cancelProcess} processes={workspace.processes} />}
        {displayStage === "clarify" && planning?.stage === "clarify" && <section className="task-detail-hero-card creation-clarify-panel">
          <header className="creation-stage-heading"><span className="creation-stage-icon"><Lightbulb size={20} /></span><div><h1>{planning.questions.length === 2 ? "再明确两个关键信息" : "还差一个关键信息"}</h1><p>知道你想达到什么结果，才能规划合适的任务。</p></div></header>
          <form onSubmit={event => { event.preventDefault(); void generatePlan(workspace.answers); }}>
            <ClarificationFields answers={workspace.answers} disabled={busy} onAnswer={(field, value) => { setWorkspace(current => ({ ...current, answers: { ...current.answers, [field]: value } })); setError(""); }} questions={planning.questions} />
            <div className="creation-request-actions"><span>期限与人选可以在方案中补充</span><Button className="creation-primary" disabled={busy || planning.questions.some(question => !workspace.answers[question.field]?.trim())} size="lg" type="submit"><Sparkles size={16} />生成任务方案</Button></div>
            {error && <p className="creation-stage-error" role="alert">{error}</p>}
          </form>
        </section>}
        {displayStage === "decision" && form?.candidate && <section className="task-detail-hero-card creation-decision">
          <header className="creation-stage-heading"><span className="creation-stage-icon"><GitBranch size={20} /></span><div><h1>{form.candidateKind === "parent" ? "这项工作，可以放进已有任务" : "先确认，是不是同一件事"}</h1><p>{form.candidateKind === "parent" ? "作为子任务将继承主任务目标；也可以独立规划。" : "请核对这项已有任务，确认关系后再继续。"}</p></div></header>
          <TaskCreationExistingTaskCard kind={form.candidateKind!} ownerName={members.find(member => member.id === form.candidate?.ownerId)?.name} reason={form.candidateReason ?? ""} tags={tags} task={form.candidate} />
          <div className="creation-decision-actions"><Button className="creation-primary" onClick={() => { if (form.candidateKind === "parent") resolveRelationship("attach"); else if (existingTasks.some(task => task.id === form.candidate?.id)) onOpenTask(form.candidate!.id); else setError("已有任务已不存在，需求已保留，请重新规划。"); }} size="lg" type="button">{form.candidateKind === "parent" ? "作为子任务继续" : "查看已有任务"}<ArrowRight size={15} /></Button><Button onClick={() => resolveRelationship("independent")} type="button" variant="outline">仍然独立规划</Button></div>
          <p className="creation-stage-note">此处只确认归属，不会创建任务，也不会修改已有任务。</p>
          {error && <p className="creation-stage-error" role="alert">{error}</p>}
        </section>}
        {displayStage === "review" && form && <>
          {result && <div className="creation-plan-summary"><span role="status"><CheckCheck size={16} />任务已创建</span><p>完成标准、人员与前置依赖已保存。</p></div>}
          <TaskCreationPlanEditor disabled={Boolean(result) || busy || adjustmentRunning} form={form} members={members} tags={tags} onChange={updateForm} onChangeRelationship={resolveRelationship} onSubtaskDirtyChange={onSubtaskDirtyChange} />
          {hasUnsavedSubtasks && <p className="creation-error" role="status">{unsavedMessage}</p>}
          {adjustmentNotice && <p className="task-ai-inline-notice" role="status"><Check size={14} />{adjustmentNotice}</p>}
          <footer className="creation-confirm-bar">
            <div className="creation-confirm-copy"><span className="creation-confirm-icon">{result ? <CheckCheck /> : <Layers3 />}</span><div><strong>{result ? "已创建 " + result.createdCount + " 个任务" : form.subtasks.length ? "1 个主任务 · " + form.subtasks.length + " 个子任务" : form.decision === "attach" ? "1 个子任务" : "1 个任务"}</strong><span>{result ? "已加入任务列表" : "确认后加入任务列表 · 其他成员人选仍待接受"}</span></div></div>
            <div className="creation-confirm-actions">{result && <Button onClick={startAnother} type="button" variant="ghost"><Plus size={14} />继续创建</Button>}<Button className="creation-primary" disabled={!result && Boolean(validation || aiOpen || busy || adjustmentRunning || hasUnsavedSubtasks)} onClick={() => result ? onOpenTask(result.mainTaskId) : submit()} size="lg" type="button">{result ? "查看任务" : "确认创建"}{result ? <ArrowRight size={17} /> : <Check size={17} />}</Button></div>
            {!result && (error || validation) && <p className="creation-validation" role={error ? "alert" : "status"}>{error || validation}</p>}
          </footer>
        </>}
      </>}
    </motion.div></AnimatePresence>
    {aiScope && aiContext && !result && <TaskAiAdjustmentPopover anchor={aiReturnFocus.current} compactCreation context={aiContext} draftSession={aiDraftSession} interactionBoundary={aiReturnFocus.current?.closest(".creation-process") ?? null} onApply={applyAiAdjustment} onOpenChange={setAiOpen} onProgressChange={updateAdjustmentProgress} open={aiOpen && active} scope={aiScope} />}
  </section>;
}
