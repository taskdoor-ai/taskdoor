import React, { useId } from "react";
import { getTaskBurnUpModel, type TaskBurnUpSeries } from "../lib/taskBurnUp";

function hours(value: number | null) {
  return value === null ? "未知" : value.toLocaleString("zh-CN", { maximumFractionDigits: 2 });
}

function progressLabel(ratio: number) {
  if (ratio > 0 && ratio < .001) return "<0.1%";
  if (ratio < 1 && ratio > .999) return ">99.9%";
  return `${Number((ratio * 100).toFixed(1))}%`;
}

function shortDate(value: string) {
  return new Intl.DateTimeFormat("zh-CN", { month: "2-digit", day: "2-digit", timeZone: "Asia/Shanghai" }).format(new Date(value));
}

function recordDate(value: string) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  return new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23", timeZone: "Asia/Shanghai" }).format(new Date(value));
}

export function TaskBurnUpSparkline({ series, effort }: { series?: TaskBurnUpSeries; effort?: React.ReactNode }) {
  const model = getTaskBurnUpModel(series, { width: 196, height: 52 });
  const titleId = useId();
  const { latest, coverage } = model;
  const hasCoordinates = model.points.some((point) => point.scopeY !== null || point.completedY !== null);
  const incompleteEstimate = Boolean(coverage && !coverage.isComplete);
  const unknownHours = Boolean(latest && (latest.scopeHours === null || latest.completedHours === null));
  const currentDataIssue = incompleteEstimate || unknownHours;
  const estimateLabel = incompleteEstimate ? "估算不完整" : "工作量未知";
  const historicalGap = model.state === "partial" && !currentDataIssue;
  const status = model.state === "invalid" ? "数据待核对"
    : model.state === "empty" ? "暂无趋势"
      : model.state === "single" ? "历史不足"
        : currentDataIssue ? estimateLabel
          : historicalGap ? "历史含未估算记录" : null;

  return <section aria-label="任务燃起图" className="task-burnup" data-has-effort={Boolean(effort)} data-source={model.source ?? undefined} data-state={model.state}>
    {effort && <div className="task-burnup-effort">{effort}</div>}
    <div className="task-burnup-heading"><span>燃起图</span><small>EWD · h</small>{model.source === "example" && <span className="task-heading-example">示例</span>}</div>
    {model.progressRatio !== null && <div className="task-burnup-progress"><span>已验收工作量</span><strong>{progressLabel(model.progressRatio)}</strong></div>}
    {latest && model.state !== "invalid" && <div className="task-burnup-values">
      <span><i aria-hidden="true" className="task-burnup-key is-completed" />已验收 <strong>{hours(latest.completedHours)}</strong></span>
      <span><i aria-hidden="true" className="task-burnup-key is-scope" />范围 <strong>{hours(latest.scopeHours)}</strong></span>
    </div>}
    {hasCoordinates && <svg aria-labelledby={titleId} className="task-burnup-chart" role="img" viewBox={`0 0 ${model.width} ${model.height}`}>
      <title id={titleId}>EWD 燃起趋势：虚线为范围，实线为已验收工作量；详细数值见下方数据表。</title>
      {model.scopePath && <path className="task-burnup-scope" d={model.scopePath} fill="none" />}
      {model.completedPath && <path className="task-burnup-completed" d={model.completedPath} fill="none" />}
      {model.points.map((point, index) => <React.Fragment key={point.timestamp}>
        {point.scopeY !== null && (index === model.points.length - 1 || (model.points[index - 1]?.scopeY == null && model.points[index + 1]?.scopeY == null)) && <circle className="task-burnup-scope-point" cx={point.x} cy={point.scopeY} r={1.8} />}
        {point.completedY !== null && (index === model.points.length - 1 || (model.points[index - 1]?.completedY == null && model.points[index + 1]?.completedY == null)) && <circle className="task-burnup-completed-point" cx={point.x} cy={point.completedY} r={1.8} />}
      </React.Fragment>)}
    </svg>}
    {status && <p className="task-burnup-state">{status}
      {model.state === "empty" && <small>尚无 EWD 历史记录</small>}
      {model.state === "invalid" && <small>{model.issue}</small>}
      {currentDataIssue && coverage && <small>{model.state === "single" && `${estimateLabel} · `}{incompleteEstimate ? `已估算 ${coverage.estimatedLeafCount}/${coverage.totalLeafCount} 项` : "工时值尚未记录"}</small>}
    </p>}
    {model.points.length > 0 && <div className="task-burnup-footer">
      <span>{model.startAt && shortDate(model.startAt)}{model.endAt !== model.startAt && model.endAt && ` — ${shortDate(model.endAt)}`}</span>
      <details className="task-burnup-details">
        <summary>查看数据</summary>
        <div className="task-burnup-data">
          <p>EWD 为预估人类工时，仅累计当前范围内的叶子任务；实线按已验收工作量记录，不按任务个数计算。</p>
          {model.source === "example" && <p className="task-burnup-example-note">示例数据，不代表当前任务的实际进度。</p>}
          {model.state === "single" && <p>历史不足：目前只有一条记录，不推测此前趋势。</p>}
          {currentDataIssue && <p>{estimateLabel}：未知值留空断线，不计算总体完成率。</p>}
          {historicalGap && <p>历史含未估算记录；当前估算已补齐，不回填过去的未知值。</p>}
          <p>时间戳按北京时间显示；日期型记录保留原日期。</p>
          <div className="task-burnup-table-scroll" role="region" aria-label="燃起图数据" tabIndex={0}>
            <table>
              <caption>范围与已验收工作量（h）</caption>
              <thead><tr><th scope="col">日期</th><th scope="col">范围</th><th scope="col">已验收</th><th scope="col">估算覆盖</th></tr></thead>
              <tbody>{model.points.map((point) => <tr key={point.timestamp}>
                <th scope="row"><time dateTime={point.at}>{recordDate(point.at)}</time>{point.note && <small>{point.note}</small>}</th>
                <td>{hours(point.scopeHours)}</td><td>{hours(point.completedHours)}</td><td>{point.estimatedLeafCount}/{point.totalLeafCount}</td>
              </tr>)}</tbody>
            </table>
          </div>
        </div>
      </details>
    </div>}
  </section>;
}
