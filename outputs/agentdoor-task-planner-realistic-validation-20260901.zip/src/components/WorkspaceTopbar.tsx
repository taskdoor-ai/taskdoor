import { Moon, Settings2, Sun } from "lucide-react";
import { GlobalNotifications } from "./GlobalNotifications";
import { PersonAvatar } from "./PersonAvatar";
import type { PersonalCenterModule } from "./PersonalInfoDialog";
import { TeamSwitcher, type SwitchableTeam } from "./TeamSwitcher";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import "../styles/workspace-shell.css";

type WorkspaceTopbarProps = {
  activeTeamId: string;
  onOpenPersonalCenter: (module: PersonalCenterModule) => void;
  onOpenTaskInsight: (taskId: string) => void;
  onTeamChange: (teamId: string) => void;
  teams: SwitchableTeam[];
  theme: "light" | "dark";
  toggleTheme: () => void;
  userId: string;
  userProfile: { name: string };
};

export function WorkspaceTopbar({ activeTeamId, onOpenPersonalCenter, onOpenTaskInsight, onTeamChange, teams, theme, toggleTheme, userId, userProfile }: WorkspaceTopbarProps) {
  return <header aria-label="工作区工具栏" className="workspace-topbar">
    <div className="workspace-topbar-inner">
      <div className="workspace-topbar-team">
        <TeamSwitcher activeTeamId={activeTeamId} onTeamChange={onTeamChange} teams={teams} variant="topbar" />
      </div>
      <div className="workspace-topbar-actions">
        <GlobalNotifications onOpenTaskInsight={onOpenTaskInsight} placement="topbar" />
        <DropdownMenu>
          <DropdownMenuTrigger aria-label="打开设置菜单" className="workspace-account-trigger" id="workspace-account-trigger" title={`${userProfile.name} · 设置`}>
            <PersonAvatar name={userProfile.name} personId={userId} profilePreviewFocusable={false} showProfilePreview={false} size="sm" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" aria-label="设置菜单" className="workspace-account-menu" sideOffset={8}>
            <DropdownMenuItem onClick={() => onOpenPersonalCenter("profile")}><Settings2 aria-hidden="true" /><span>设置</span></DropdownMenuItem>
            <DropdownMenuItem onClick={toggleTheme}>{theme === "light" ? <Moon aria-hidden="true" /> : <Sun aria-hidden="true" />}<span>{theme === "light" ? "切换到深色" : "切换到浅色"}</span></DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  </header>;
}
