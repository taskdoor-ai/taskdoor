import { Check, ChevronDown, Circle, CirclePause, CircleAlert, LoaderCircle } from "lucide-react";
import { useEffect, useId, useState, type ReactNode } from "react";
import { getCreationProcessStepState, type CreationProcess } from "../lib/taskCreationProgress";
import { AgentActivityIndicator } from "./ui/ai-agent-response";
import { Button } from "./ui/button";

/** Reuses the old workflow's disclosure interaction, driven only by the page's playback. */
export function TaskCreationProcess({ processes, onCancel, actions }: {
  processes: CreationProcess[];
  onCancel?: () => void;
  actions?: ReactNode;
}) {
  const current = processes.at(-1);
  const running = current?.status === "running";
  const [expanded, setExpanded] = useState(running);
  const [openSteps, setOpenSteps] = useState<Record<string, boolean>>({});
  const contentId = useId();

  useEffect(() => {
    setExpanded(running);
    setOpenSteps({});
  }, [current?.id, running]);

  if (!current) return null;
  const adjusting = current.kind === "adjustment";
  const currentStep = current.steps[current.activeStep];
  const statusText = running ? `${currentStep?.label ?? "整理需求"} · ${current.activeStep + 1}/${current.steps.length || 1}`
    : current.status === "stopped" ? "已停止" : current.status === "failed" ? adjusting ? "调整未完成" : "未生成方案" : current.outcome;

  return <section aria-label="任务生成过程" className="creation-process">
    <header className="creation-process-header">
      <button aria-controls={contentId} aria-expanded={expanded} className="creation-process-toggle" onClick={() => setExpanded(value => !value)} type="button">
        <AgentActivityIndicator active={running} />
        <strong className={running ? "agent-workflow-gradient-text" : undefined}>{running ? adjusting ? "正在调整方案" : "正在生成方案" : expanded ? "收起生成过程" : "查看生成过程"}</strong>
        <span className="creation-process-status">{statusText}</span>
        <ChevronDown aria-hidden="true" className={expanded ? "is-open" : undefined} size={14} />
      </button>
      {(actions || (running && onCancel)) && <div className="creation-process-actions">
        {running && onCancel && <Button aria-label={adjusting ? "停止调整方案" : "停止生成方案"} onClick={onCancel} size="sm" type="button" variant="ghost">停止</Button>}
        {actions}
      </div>}
    </header>
    {running && <span aria-atomic="true" className="sr-only" role="status">{statusText}</span>}
    {expanded && <div className="creation-process-content" id={contentId}>
      <section className="creation-process-run" key={current.id}>
        {(current.answers.goal || current.answers.deliverable) && <dl className="creation-process-answers">
          {current.answers.goal && <div><dt>补充目标</dt><dd>{current.answers.goal}</dd></div>}
          {current.answers.deliverable && <div><dt>交付内容</dt><dd>{current.answers.deliverable}</dd></div>}
        </dl>}
        <ol aria-label={`${current.title}的步骤`} className="creation-process-steps">
          {current.steps.map((step, index) => {
            const state = getCreationProcessStepState(current, index);
            const key = `${current.id}-${index}`;
            const isActive = state === "running";
            const open = state !== "pending" && (openSteps[key] ?? isActive);
            const label = state === "completed" ? "已整理" : state === "running" ? "进行中" : state === "stopped" ? "已停止" : state === "failed" ? "未完成" : current.status === "running" ? "待处理" : "未进行";
            const StepIcon = state === "completed" ? Check : state === "stopped" ? CirclePause : state === "failed" ? CircleAlert : Circle;
            return <li className="agent-workflow-trace" data-state={state} key={key}>
              <button aria-controls={`${contentId}-${key}`} aria-expanded={open} className="agent-workflow-trace-toggle" disabled={state === "pending"} onClick={() => setOpenSteps(value => ({ ...value, [key]: !open }))} type="button">
                {isActive ? <LoaderCircle aria-hidden="true" className="creation-process-step-spinner" size={14} /> : <StepIcon aria-hidden="true" size={14} />}
                <strong className={isActive ? "agent-workflow-gradient-text" : undefined}>{step.label}</strong><span className="creation-process-step-status">{label}</span><ChevronDown aria-hidden="true" className={open ? "is-open" : undefined} size={13} />
              </button>
              {open && <div className="agent-workflow-trace-content" id={`${contentId}-${key}`}><p>{step.detail}</p><p className="creation-process-basis"><span>依据</span>{step.basis}</p></div>}
            </li>;
          })}
        </ol>
      </section>
    </div>}
  </section>;
}
